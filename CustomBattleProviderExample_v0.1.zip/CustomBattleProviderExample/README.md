# Custom Battle Provider Example

This is an adapter example, not a model pack. It contains no Pokemon models or
textures.

Replace the placeholder `MY_CUSTOM_MODELS_API` with your own model loader, or
copy the three exported provider tables into your existing mod.

The important exports are:

* `battleModelProvider` - supplies any available custom Pokemon model.
* `battleMoveFX` - optionally maps live moves to your own VFX records.
* `battleMoveBehavior` - remaps/defines realtime targeting behavior.

You do not need to edit 368RealtimeBattleDX or hardcode your mod id into it.
