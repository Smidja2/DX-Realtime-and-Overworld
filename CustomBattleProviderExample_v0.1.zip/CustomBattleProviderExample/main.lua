local mod=...

-- This example intentionally contains NO copyrighted Pokemon assets.
-- Replace `MyCustomModels` / `MyCustomEffects` with your mod's own loader.
local MyCustomModels=rawget(_G,"MY_CUSTOM_MODELS_API")
local MyCustomEffects=rawget(_G,"MY_CUSTOM_BATTLE_FX_API")

-- EASY MODEL PROVIDER ------------------------------------------------------
-- 368RealtimeBattleDX automatically discovers this export. No hard dependency
-- or package-id allowlist is required.
mod.exports.battleModelProvider={
  version=1,
  priority=250,
  worldUnits=false,

  selected=function(context)
    return MyCustomModels~=nil
  end,

  hasSpecies=function(speciesId)
    if not MyCustomModels then return false end
    if type(MyCustomModels.hasSpecies)=="function" then
      return MyCustomModels.hasSpecies(speciesId)~=false
    end
    return true
  end,

  createActor=function(speciesId,opts)
    if not MyCustomModels or type(MyCustomModels.createActor)~="function" then
      return nil,"MY_CUSTOM_MODELS_API.createActor is unavailable"
    end
    -- Your own actor can be any Lua table/object. It only needs matrix+draw;
    -- animation/lifecycle methods are optional.
    return MyCustomModels.createActor(speciesId,opts)
  end,

  -- If your returned actor already implements matrix() and draw(), delete
  -- these two forwarding methods.
  matrix=function(actor,x,y,z,faceX,faceZ)
    return actor:matrix(x,y,z,faceX,faceZ)
  end,
  draw=function(actor,matrix,alpha)
    return actor:draw(matrix,alpha)
  end,

  -- Optional generic animation bridge. The host requests standard semantic
  -- names; translate them here if your files use different clip names.
  animations={
    idle="idle",walk="walk",fly="fly",attack="attack",hit="hit",
    faint="faint",sleep="sleep",spawn="spawn",recall="recall",
  },
  setAnimation=function(actor,name,...)
    if actor and type(actor.setAnimation)=="function" then
      return actor:setAnimation(name,...)
    end
  end,

  -- Optional renderer setup. Omit this entirely if actor:draw() already works
  -- in the battle arena's active render target.
  withRenderer=function(vp,callback,opts)
    if MyCustomModels and type(MyCustomModels.withRenderer)=="function" then
      return MyCustomModels.withRenderer(vp,callback,opts)
    end
    return callback()
  end,
}

-- MOVE / VFX PROVIDER ------------------------------------------------------
mod.exports.battleMoveFX={
  version=1,
  priority=250,
  selected=function(context) return MyCustomEffects~=nil end,

  resolveMoveId=function(moveId)
    if MyCustomEffects and type(MyCustomEffects.resolveMoveId)=="function" then
      return MyCustomEffects.resolveMoveId(moveId)
    end
    return nil
  end,

  vfxForMove=function(moveId)
    if MyCustomEffects and type(MyCustomEffects.vfxForMove)=="function" then
      return MyCustomEffects.vfxForMove(moveId)
    end
    return nil
  end,

  readVFX=function(ref)
    if MyCustomEffects and type(MyCustomEffects.readVFX)=="function" then
      return MyCustomEffects.readVFX(ref)
    end
    return nil
  end,
}

-- REALTIME MOVE BEHAVIOR ---------------------------------------------------
-- Example custom move 9001 uses Thunderbolt's existing line/range behavior.
-- Move mechanics still come from the normal battle engine.
mod.exports.battleMoveBehavior={
  version=1,
  priority=250,
  profile=function(moveId,moveDef,context)
    if tonumber(moveId)==9001 or tostring(moveId)=="MY_CUSTOM_BOLT" then
      return {remapTo="THUNDERBOLT"}
    end

    -- Example of a completely custom spatial profile:
    if tostring(moveId)=="MY_CUSTOM_FIREBALL" then
      return {class="PROJECTILE",range=20,radius=1.25}
    end

    -- nil means: let 368RealtimeBattleDX use its built-in targeting table.
    return nil
  end,
}
