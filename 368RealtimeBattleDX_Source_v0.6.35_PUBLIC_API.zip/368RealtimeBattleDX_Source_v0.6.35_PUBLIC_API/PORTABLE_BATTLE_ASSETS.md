# Portable Battle Assets v1

The realtime battle should own combat flow, not Pokemon art assets.

## 1. Pokemon model provider

Use the already-supported `exports.battleActors` v1 capability. At minimum:

```lua
mod.exports.battleActors = {
  version = 1,
  portable = true,
  priority = 100,
  selected = function(context) return true end, -- optional
  available = function(source, dex) return true end, -- optional
  acquire = function(source, dex, variant, opts)
    -- Return an actor object or nil,error.
  end,
  withRenderer = function(vp, callback, opts)
    return callback()
  end,
}
```

The returned actor should implement the operations the battle presentation uses, such as position/facing updates plus `attack(moveId, moveDef)`, `hit(payload)`, `faint()`, `update(dt)`, and `remove(reason)`/`release()` where applicable. Providers may expose extra metrics/body-point helpers; the battle runtime fails open when optional presentation data is missing.

The provider is selected by capability and priority, not by package name. A species that is unavailable can fall back to the normal sprite path.

## 2. Move/VFX provider

Publish `exports.battleMoveFX`:

```lua
mod.exports.battleMoveFX = {
  version = 1,
  priority = 100,

  -- Optional. Return false to decline the current battle/context.
  selected = function(context)
    return true
  end,

  -- Optional. Useful when the game's move IDs/names differ from the asset pack.
  resolveMoveId = function(moveId)
    return numericAssetMoveId, canonicalMoveName
  end,

  -- Return a presentation record for the live move.
  -- The provider may also return the resolved numeric id/name.
  vfxForMove = function(moveId)
    return vfxRecord, numericAssetMoveId, canonicalMoveName
  end,

  -- Optional raw-resource reader used by low-level effect decoders/probes.
  readVFX = function(ref)
    return rawBytes
  end,
}
```

This is deliberately presentation-only. The provider does NOT decide damage, accuracy, PP, EXP, status, fainting, switching, or battle results.

## 3. Move behavior remapping

Realtime movement/targeting should map the game's live move definition into a small behavior family instead of hardcoding species:

- contact / melee
- projectile
- stream / beam
- target-line / lane
- radial / explosion
- ground AoE / trap
- cone
- self / buff / heal
- special scripted families (Teleport, Transform, Metronome, Bide, Counter, Seismic Toss, etc.)

The move ID chooses behavior + presentation. The Pokemon species only supplies the actor/model and its native attack animation.


## 4. Public high-level model adapter

Custom packs may export `battleModelProvider` instead of implementing the full
`battleActors` service. The host wraps `createActor + matrix + draw` into the
portable actor contract and forwards optional animation callbacks.

## 5. Custom move behavior provider

Export `battleMoveBehavior` to override realtime targeting metadata or map a
custom move onto an existing profile with `{ remapTo="THUNDERBOLT" }`.

See `PUBLIC_MODDING_API.md`.
