# 368RealtimeBattleDX Public Modding API v1

The realtime battle core is intentionally separate from the Pokemon model pack,
move-effect pack, and move-targeting metadata. Other mods can plug in without
editing `RealtimeBattle.lua`.

## Recommended integration: export capabilities

This is the easiest and most load-order-safe route. Your mod simply publishes
one or more exports.

### A. Simple custom Pokemon model provider

```lua
local mod=...

mod.exports.battleModelProvider = {
  version = 1,
  priority = 200,          -- higher selected provider wins
  worldUnits = false,      -- true only if your matrices use stage world units

  -- Optional. Return false if your pack should not own the current battle.
  selected = function(context)
    return true
  end,

  -- Optional. Decline individual species and the host falls back for that side.
  hasSpecies = function(speciesId)
    return speciesId >= 1 and speciesId <= 151
  end,

  -- Required. Return your own actor/model object.
  createActor = function(speciesId, opts)
    -- opts.side      = "player" or "enemy"
    -- opts.context   = current battle presentation context
    -- opts.battler   = live Gen1Recomp battler
    -- opts.variant   = presentation variant string
    -- opts.source    = provider source selection
    return MyModels.create(speciesId)
  end,

  -- Required either here or on the returned actor object.
  matrix = function(actor,x,y,z,faceX,faceZ)
    return actor:matrix(x,y,z,faceX,faceZ)
  end,
  draw = function(actor,matrix,alpha)
    return actor:draw(matrix,alpha)
  end,

  -- Optional. If omitted, the host calls the render callback directly.
  withRenderer = function(vp,callback,opts)
    MyModels.begin3D(vp)
    local result=callback()
    MyModels.end3D()
    return result
  end,

  -- Optional animation bridge. The host automatically requests these names:
  -- spawn, idle, walk, fly, attack, hit, faint, sleep, recall.
  setAnimation = function(actor,name,...)
    return actor:setAnimation(name,...)
  end,
}
```

The returned actor may implement callbacks itself instead of putting them on the
provider. Supported optional callbacks include `update`, `build`, `spawn`,
`idle`, `locomotion`, `attack`, `hit`, `faint`, `sleep`, `recall`, `remove`,
`release`, and `attachment`.

If your animation names differ, provide an alias table:

```lua
animations = {
  idle="Idle_A",
  walk="Run01",
  fly="Fly_Loop",
  attack="Attack01",
  hit="Damage",
  faint="Faint",
}
```

The adapter never decides battle mechanics. Actor callbacks are presentation
notifications only.

### B. Full low-level actor provider

Advanced renderers can still export `battleActors` v1 directly. See
`PORTABLE_BATTLE_ACTORS.md`.

### C. Move / VFX provider

```lua
mod.exports.battleMoveFX = {
  version = 1,
  priority = 200,

  -- Optional remap from the game's live move id/name to your asset id.
  resolveMoveId = function(moveId)
    if moveId=="THUNDERBOLT" then return 85,"THUNDERBOLT" end
  end,

  -- Return your effect record plus optional resolved id/name.
  vfxForMove = function(moveId)
    return MyEffects.forMove(moveId)
  end,

  -- Optional raw effect reader for lower-level effect runtimes.
  readVFX = function(ref)
    return MyEffects.read(ref)
  end,
}
```

`battleMoveProvider` is accepted as an alias.

### D. Move behavior / targeting remap

This controls only realtime spatial handling. The native battle engine still
performs PP, accuracy, damage, status, fainting, switching, EXP, etc.

```lua
mod.exports.battleMoveBehavior = {
  version = 1,
  priority = 200,
  profile = function(moveId,moveDef,context)
    -- Easiest: make a custom move inherit an existing realtime profile.
    if tonumber(moveId)==9001 then
      return { remapTo="THUNDERBOLT" }
    end

    -- Or define it directly.
    if tostring(moveId)=="MY_FIREBALL" then
      return { class="PROJECTILE", range=20, radius=1.25 }
    end

    -- nil = use 368RealtimeBattleDX's built-in Gen I-III table.
    return nil
  end,
}
```

Supported core classes are:

`MELEE`, `DASH`, `PROJECTILE`, `HOMING_PROJECTILE`, `LINE`, `CONE`,
`TARGETED`, `GROUND_AOE`, `TRAP_ZONE`, `SELF`, `SELF_AOE`, `FIELD`, `SPECIAL`.

Common profile fields are `range`, `radius`, `width`, `angle`, `groundTarget`,
`persistent`, `homing`, `selfField`, and `selfAoe`.

## Optional direct registration API

Instead of exports, a late-loaded mod can locate `XD_BATTLE_ENVIRONMENTS` and
use:

```lua
local api=battleMod.exports.realtimeBattleAPI
api.registerModelProvider("MY_MODELS",myModelProvider)
api.registerMoveFXProvider("MY_FX",myMoveFX)
api.registerMoveBehaviorProvider("MY_MOVES",myMoveBehavior)
```

Matching unregister calls are provided. `battleFramework` is an alias for
`realtimeBattleAPI`.

The older `battleCompatibility.register(owner,kind,provider)` facade also
accepts `battleModelProvider`, `battleMoveFX`, and `battleMoveBehavior`.

## Provider priority and fallback

* Highest selected `priority` wins.
* A model provider may decline a species with `hasSpecies=false`; that battler
  falls back instead of killing the whole battle presentation.
* A move behavior provider may return `nil`; the built-in profile is used.
* A move/VFX provider may omit a mapping; the runtime may use its normal/rebuilt
  presentation fallback.
* XD remains a compatibility fallback; it is no longer the only valid source.

## What a custom pack does NOT need to implement

A model/VFX pack does not need to reproduce Gen1Recomp battle rules. Do not
write damage, PP, EXP, accuracy, status, switch, faint-result or victory logic in
the provider. 368RealtimeBattleDX only asks the provider how to present the live
battle state.
