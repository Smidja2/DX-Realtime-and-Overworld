# 368RealtimeBattleDX - generic source snapshot

This folder is a source-code snapshot extracted from the current unified battle builder, with one portability refactor applied:

- Pokemon models are selected through the existing `battleActors` v1 capability. The realtime battle does not need to know whether the model came from Pokemon XD, Stadium, another model importer, or a future provider.
- Move presentation can now be supplied through a new `battleMoveFX` v1 capability.
- The existing `POKEMON_XD_GEN1` / `368ImporterDX` API remains a compatibility fallback, so the XD setup still works without changing the importer first.
- Gen1Recomp remains authoritative for Pokemon, moves, PP, HP, damage, status, EXP, fainting, switching, battle results, etc. Providers only supply presentation/actor behavior.

## Important

This is SOURCE, not a ready-to-install generated mod. The installable battle mod still needs a generated `manifest.json` tied to the exact locally generated `368BattlePackDX.pack` size/MD5.

## Generic model idea

A model mod can publish `exports.battleActors` v1. `CurrentSpriteModels.lua` discovers the highest-priority selected compatible provider and falls back to sprites per species if no actor is available.

## Generic move/VFX idea

A VFX/importer mod can publish `exports.battleMoveFX` v1. `BattleAssetProvider.lua` discovers it and `RealtimeBattle.lua` asks it to resolve live move IDs / effect records. If none exists, the old XD API is used.

See `PORTABLE_BATTLE_ASSETS.md` and the existing `PORTABLE_BATTLE_ACTORS.md`.

## Public custom-model / move API (v0.6.35)

This source tree now exposes `mod.exports.realtimeBattleAPI` and automatic
capability discovery for `battleModelProvider`, `battleMoveFX`, and
`battleMoveBehavior`. See `PUBLIC_MODDING_API.md`, `CUSTOM_MODEL_QUICKSTART.md`,
and `examples/CustomBattleProviderExample/`.
