-- Lightweight required-import/cache compatibility bridge for the HTML-generated
-- XD battle-stage pack. Native mod.imports is left untouched. On older hosts,
-- the small pack may be buffered through mod:read instead of importing a full
-- GameCube disc.
local M={}
local IMPORT_ID="pokemon_xd_stage_pack"
local IMPORT_PATHS={
  "baseroms/368BattlePackDX.pack",
  "368BattlePackDX.pack",
}
local CACHE_ROOT="xdbe_generated_v3"

local function safeCachePath(path)
  assert(type(path)=="string" and path~="","cache path is required")
  path=path:gsub("\\","/")
  assert(path:sub(1,1)~="/" and not path:match("^%a:"),"absolute cache path rejected")
  assert(not path:find("../",1,true) and path~=".." and not path:find("/..",1,true),"cache path traversal rejected")
  return CACHE_ROOT.."/"..path
end

local function makeLegacyImports(mod,status)
  local sourceBlob=nil;local sourcePath=nil;local sourceSize=nil
  local function locate()
    if sourcePath then return sourcePath,sourceSize end
    if type(mod.info)~="function" then return nil,"mod:info is unavailable" end
    for _,path in ipairs(IMPORT_PATHS) do
      local ok,info=pcall(mod.info,mod,path)
      if ok and info and (not info.type or info.type=="file") then
        sourcePath=path;sourceSize=tonumber(info.size);return sourcePath,sourceSize
      end
    end
    return nil,"launcher stage-pack import is not installed"
  end
  local imports={}
  function imports:info(id)
    if id~=IMPORT_ID then return nil,"unknown import: "..tostring(id) end
    local path,size=locate();if not path then return nil,size end
    return {id=IMPORT_ID,file=path,size=size,type="file",validated=true}
  end
  function imports:read(id,offset,length)
    local info,err=self:info(id);if not info then return nil,err end
    offset=tonumber(offset);length=tonumber(length)
    if not offset or not length or offset<0 or length<0 or offset%1~=0 or length%1~=0 then return nil,"invalid import read range" end
    if not info.size or offset+length>info.size then return nil,"import read exceeds stage pack" end
    if length==0 then return "" end
    if sourceBlob==nil then
      local bytes,readErr=mod:read(info.file)
      if type(bytes)~="string" then return nil,readErr or "stage pack could not be read" end
      if #bytes~=info.size then return nil,("stage-pack read returned %d bytes; expected %d"):format(#bytes,info.size) end
      sourceBlob=bytes;status.sourceBuffered=true
    end
    return sourceBlob:sub(offset+1,offset+length)
  end
  function imports:release()sourceBlob=nil;status.sourceBuffered=false;collectgarbage("collect");return true end
  return imports
end

function M.install(mod)
  assert(type(mod)=="table","XD stage-pack launcher bridge requires mod API")
  local status={source="launcher required_imports",sourcePath="368BattlePackDX.pack",sourceBuffered=false}
  if mod.imports then
    status.importBridge="native mod.imports"
    status.nativeRangeImports=true
  else
    rawset(mod,"imports",makeLegacyImports(mod,status))
    status.importBridge="legacy mod:read stage-pack adapter"
    status.nativeRangeImports=false
  end

  if not mod.cache then
    local fs=love and love.filesystem
    assert(fs and type(fs.read)=="function" and type(fs.write)=="function" and type(fs.getInfo)=="function",
      "Gen1Recomp per-mod filesystem compatibility overlay is unavailable")
    local cache={}
    local function ensureParent(full)
      local parent=tostring(full or ""):match("^(.*)/[^/]+$")
      if not parent or parent=="" or type(fs.createDirectory)~="function" then return true end
      local cur=""
      for part in parent:gmatch("[^/]+") do
        cur=(cur=="" and part) or (cur.."/"..part)
        local ok,err=fs.createDirectory(cur);if ok==false then return false,err end
      end
      return true
    end
    function cache:info(path)return fs.getInfo(safeCachePath(path))end
    function cache:read(path)return fs.read(safeCachePath(path))end
    function cache:write(path,data)
      assert(type(data)=="string","cache writes require string bytes")
      if #data>64*1024*1024 then return false,"cache write exceeds the API-2 64 MiB per-key limit" end
      local full=safeCachePath(path);local ok,err=ensureParent(full);if ok==false then return false,err end
      return fs.write(full,data)
    end
    function cache:delete(path)
      local full=safeCachePath(path);if not fs.getInfo(full) then return true end
      local ok,err=fs.remove(full);if ok==false then return false,err end;return true
    end
    rawset(mod,"cache",cache);status.cacheBridge="legacy filesystem overlay adapter"
  else status.cacheBridge="native mod.cache" end
  return status
end
return M
