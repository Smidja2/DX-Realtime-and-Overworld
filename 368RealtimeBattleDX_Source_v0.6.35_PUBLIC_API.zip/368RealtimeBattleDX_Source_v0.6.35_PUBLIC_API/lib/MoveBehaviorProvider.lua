-- Portable realtime move-behavior provider for 368RealtimeBattleDX.
--
-- Providers are layered per move. Returning nil declines that move and lets the
-- next provider (then the built-in Gen I-III table) answer it.
local V=...
local M={version=1}
local ModLookup=V.ModLookup
local OWNER=(V.mod and V.mod.id) or "XD_BATTLE_ENVIRONMENTS"
local registered={}

local function selected(api,context)
  if type(api.selected)~="function" then return true end
  local ok,value=pcall(api.selected,context)
  return ok and value~=false
end

local function valid(api)
  return type(api)=="table"
    and (api.version==nil or tonumber(api.version)==1)
    and (type(api.profile)=="function" or type(api.get)=="function" or type(api.resolve)=="function")
end

local function candidates(context)
  local game=(context and context.game) or (context and context.battle and context.battle.game)
  local rows,seen={},{ }
  local function add(api,handle)
    if not (valid(api) and selected(api,context)) or seen[api] then return end
    seen[api]=true
    rows[#rows+1]={api=api,handle=handle or {id="provider",exports={}},priority=tonumber(api.priority) or 0}
  end
  local handles=ModLookup and type(ModLookup.each)=="function" and ModLookup.each(V.mod,game) or {}
  for _,handle in ipairs(handles) do
    if handle and handle.id~=OWNER then
      local exports=handle.exports or {}
      add(exports.battleMoveBehavior or exports.realtimeMoveBehavior,handle)
    end
  end
  for owner,api in pairs(registered) do add(api,{id=owner,exports={}}) end
  table.sort(rows,function(a,b)
    if a.priority~=b.priority then return a.priority>b.priority end
    return tostring(a.handle.id)<tostring(b.handle.id)
  end)
  return rows
end

local function copyTable(src)
  local out={};if type(src)=="table" then for k,v in pairs(src) do out[k]=v end end;return out
end

local function builtIn(moveId,def)
  local mt=V.MoveTargeting
  if mt and type(mt.get)=="function" then
    local ok,p=pcall(mt.get,moveId,def);if ok and type(p)=="table" then return p end
  end
  return nil
end

local function normalize(value,moveId,def)
  if value==nil or value==false then return nil end
  if type(value)=="string" then return {class=value,sourceMoveId=moveId} end
  if type(value)~="table" then return nil end
  local remap=value.remapTo or value.remap or value.inherit
  local out=remap~=nil and copyTable(builtIn(remap,def)) or {}
  for k,v in pairs(value) do
    if k~="remapTo" and k~="remap" and k~="inherit" then out[k]=v end
  end
  out.sourceMoveId=out.sourceMoveId or moveId
  if remap~=nil then out.remappedFrom=moveId;out.remappedTo=remap end
  return out
end

function M.register(owner,api)
  owner=tostring(owner or "")
  if owner=="" or owner==OWNER then return false,"invalid move-behavior provider owner" end
  if not valid(api) then return false,"invalid battleMoveBehavior v1 provider" end
  registered[owner]=api
  return true
end

function M.unregister(owner)
  owner=tostring(owner or "")
  local had=registered[owner]~=nil;registered[owner]=nil;return had
end

function M.profile(context,moveId,def)
  for _,row in ipairs(candidates(context)) do
    local api=row.api
    if type(api.hasMove)=="function" then
      local ok,has=pcall(api.hasMove,moveId,def,context);if ok and has==false then goto continue end
    end
    local fn=api.profile or api.get or api.resolve
    local ok,value=pcall(fn,moveId,def,context)
    if ok then
      local p=normalize(value,moveId,def)
      if p then return p,row.handle end
    end
    ::continue::
  end
  return builtIn(moveId,def),nil
end

function M.status(context)
  local rows=candidates(context)
  local owners={};for owner in pairs(registered) do owners[#owners+1]=owner end;table.sort(owners)
  local providers={};for _,r in ipairs(rows) do providers[#providers+1]=r.handle.id end
  return {ready=#rows>0,provider=rows[1] and rows[1].handle.id or nil,providers=providers,registeredOwners=owners}
end

return M
