-- Public modding facade for 368RealtimeBattleDX.
--
-- This API intentionally sits above the internal renderer. Custom model packs
-- may either export the documented capabilities directly or locate the battle
-- mod and call these registration helpers. Direct exports are recommended when
-- possible because discovery is naturally load-order safe.
local V=...
local M={version=1}
local wrapped=setmetatable({},{__mode="k"})

local function invokeActor(raw,provider,name,...)
  if raw and type(raw[name])=="function" then return raw[name](raw,...) end
  if provider and type(provider[name])=="function" then return provider[name](raw,...) end
  return nil
end

local function animName(provider,name)
  local map=provider and provider.animations
  local v=type(map)=="table" and map[name] or nil
  return v or name
end

local function setAnimation(raw,provider,name,...)
  local resolved=animName(provider,name)
  if raw and type(raw.setAnimation)=="function" then return raw:setAnimation(resolved,...) end
  if provider and type(provider.setAnimation)=="function" then return provider.setAnimation(raw,resolved,...) end
  return nil
end

local function proxyActor(raw,provider)
  local A={raw=raw,state="idle",lastMove=nil,removed=false}
  setmetatable(A,{__index=function(_,k)
    local v=raw and raw[k]
    if v~=nil then return v end
    return nil
  end})

  function A:update(dt)
    local v=invokeActor(raw,provider,"update",dt)
    return v
  end
  function A:matrix(x,y,z,faceX,faceZ)
    return invokeActor(raw,provider,"matrix",x,y,z,faceX,faceZ)
  end
  function A:build()
    if raw and type(raw.build)=="function" then return raw:build() end
    if provider and type(provider.build)=="function" then return provider.build(raw) end
    return true
  end
  function A:draw(matrix,alpha)
    return invokeActor(raw,provider,"draw",matrix,alpha)
  end
  function A:spawn(progress)
    self.state="spawn"
    local v=invokeActor(raw,provider,"spawn",progress)
    if v==nil then v=setAnimation(raw,provider,"spawn",progress) end
    return v
  end
  function A:idle()
    self.state="idle"
    local v=invokeActor(raw,provider,"idle")
    if v==nil then v=setAnimation(raw,provider,"idle") end
    return v
  end
  function A:locomotion(moving,flightState,flightMode)
    self.state=moving and (flightMode and "fly" or "walk") or "idle"
    local v=invokeActor(raw,provider,"locomotion",moving,flightState,flightMode)
    if v==nil then
      local key=moving and (flightMode and "fly" or "walk") or "idle"
      v=setAnimation(raw,provider,key,flightState,flightMode)
    end
    return v
  end
  function A:attack(moveId,moveDef)
    self.state="attack";self.lastMove=moveId
    local v=invokeActor(raw,provider,"attack",moveId,moveDef)
    if v==nil then v=setAnimation(raw,provider,"attack",moveId,moveDef) end
    return v
  end
  function A:hit(payload)
    self.state="hit"
    local v=invokeActor(raw,provider,"hit",payload)
    if v==nil then v=setAnimation(raw,provider,"hit",payload) end
    return v
  end
  function A:faint(payload)
    self.state="faint"
    local v=invokeActor(raw,provider,"faint",payload)
    if v==nil then v=setAnimation(raw,provider,"faint",payload) end
    return v
  end
  function A:sleep(payload)
    self.state="sleep"
    local v=invokeActor(raw,provider,"sleep",payload)
    if v==nil then v=setAnimation(raw,provider,"sleep",payload) end
    return v
  end
  function A:recall(reason)
    self.state="recall"
    local v=invokeActor(raw,provider,"recall",reason)
    if v==nil then v=setAnimation(raw,provider,"recall",reason) end
    return v
  end
  function A:attachment(name)
    return invokeActor(raw,provider,"attachment",name)
  end
  function A:remove(reason)
    if self.removed then return true end
    self.removed=true;self.state="removed"
    if raw and type(raw.remove)=="function" then return raw:remove(reason) end
    if provider and type(provider.remove)=="function" then return provider.remove(raw,reason) end
    if raw and type(raw.release)=="function" then return raw:release() end
    if provider and type(provider.release)=="function" then return provider.release(raw) end
    if raw and type(raw.destroy)=="function" then return raw:destroy() end
    if provider and type(provider.destroy)=="function" then return provider.destroy(raw) end
    return true
  end
  function A:release()
    return self:remove("release")
  end
  return A
end

local function validSimpleModelProvider(provider)
  return type(provider)=="table"
    and (provider.version==nil or tonumber(provider.version)==1)
    and type(provider.createActor)=="function"
end

function M.wrapModelProvider(provider,owner)
  if not validSimpleModelProvider(provider) then return nil,"invalid battleModelProvider v1" end
  local cached=wrapped[provider]
  if cached then return cached end

  local service={
    version=1,portable=true,
    priority=tonumber(provider.priority) or 0,
    worldUnits=provider.worldUnits==true,
    SELECTED=provider.SELECTED,
    _simpleProvider=provider,
    _owner=owner,
  }
  function service.selected(context)
    if type(provider.selected)~="function" then return true end
    local ok,value=pcall(provider.selected,context)
    return ok and value~=false
  end
  function service.available(source,dex)
    dex=tonumber(dex)
    if not dex then return false end
    if type(provider.hasSpecies)=="function" then
      local ok,value=pcall(provider.hasSpecies,dex)
      return ok and value~=false
    end
    if type(provider.available)=="function" then
      local ok,value=pcall(provider.available,source,dex)
      return ok and value~=false
    end
    return true
  end
  function service.acquire(source,dex,variant,opts)
    local request={}
    if type(opts)=="table" then for k,v in pairs(opts) do request[k]=v end end
    request.source=source;request.variant=variant;request.speciesId=dex
    local ok,raw,err=pcall(provider.createActor,dex,request)
    if not ok then return nil,tostring(raw) end
    if not raw then return nil,tostring(err or "custom model provider returned no actor") end
    local hasMatrix=(type(raw.matrix)=="function") or type(provider.matrix)=="function"
    local hasDraw=(type(raw.draw)=="function") or type(provider.draw)=="function"
    if not hasMatrix then return nil,"custom actor needs matrix(actor,x,y,z,faceX,faceZ)" end
    if not hasDraw then return nil,"custom actor needs draw(actor,matrix,alpha)" end
    return proxyActor(raw,provider)
  end
  function service.withRenderer(vp,callback,opts)
    if type(provider.withRenderer)=="function" then return provider.withRenderer(vp,callback,opts) end
    return callback()
  end
  function service.status()
    if type(provider.status)=="function" then
      local ok,value=pcall(provider.status)
      if ok then return value end
    end
    return {ready=true,owner=owner,simpleProvider=true}
  end
  wrapped[provider]=service
  return service
end

function M.isSimpleModelProvider(provider)
  return validSimpleModelProvider(provider)
end



-- Compose multiple low-level battleActors providers into one per-species
-- fallback service. This lets a partial custom model pack coexist with XD or
-- another pack: the highest-priority provider that actually has the requested
-- species wins. The wrapper also keeps each provider's renderer isolated, so
-- player and enemy may come from different model packs in the same battle.
local compositeCache={}

local function actorForward(raw,name,...)
  local fn=raw and raw[name]
  if type(fn)=="function" then return fn(raw,...) end
  return nil
end

local function bindLayeredActor(raw,api,providerId,renderState)
  local A={raw=raw,state=(raw and raw.state) or "idle",_providerApi=api,
    _providerId=providerId,_providerWorldUnits=api and api.worldUnits==true,removed=false}
  setmetatable(A,{__index=function(_,k)
    local v=raw and raw[k]
    if v~=nil and type(v)~="function" then return v end
    return nil
  end})
  local function call(self,name,semantic,...)
    local v=actorForward(raw,name,...)
    self.state=(raw and raw.state) or semantic or self.state
    return v
  end
  function A:update(dt) return call(self,"update",self.state,dt) end
  function A:matrix(x,y,z,fx,fz) return actorForward(raw,"matrix",x,y,z,fx,fz) end
  function A:build() if raw and type(raw.build)=="function" then return raw:build() end return true end
  function A:draw(matrix,alpha)
    local fn=raw and raw.draw
    if type(fn)~="function" then return false end
    local opts=renderState.opts or {}
    local context=opts.context
    local services=context and context.services
    local vp=(api and api.worldUnits==true and services and services.stageVP)
      or (services and services.vp) or renderState.vp
    local withRenderer=api and api.withRenderer
    if type(withRenderer)=="function" then
      local accepted,result,err=withRenderer(vp,function() return fn(raw,matrix,alpha) end,opts)
      if accepted==false then return false,err or result end
      return result==nil and accepted or result
    end
    return fn(raw,matrix,alpha)
  end
  function A:spawn(progress) return call(self,"spawn","spawn",progress) end
  function A:idle() return call(self,"idle","idle") end
  function A:locomotion(moving,flightState,flightMode)
    return call(self,"locomotion",moving and (flightMode and "fly" or "walk") or "idle",moving,flightState,flightMode)
  end
  function A:attack(moveId,moveDef) self.lastMove=moveId;return call(self,"attack","attack",moveId,moveDef) end
  function A:hit(payload) return call(self,"hit","hit",payload) end
  function A:faint(payload) return call(self,"faint","faint",payload) end
  function A:sleep(payload) return call(self,"sleep","sleep",payload) end
  function A:recall(reason) return call(self,"recall","recall",reason) end
  function A:attachment(name) return actorForward(raw,"attachment",name) end
  function A:remove(reason)
    if self.removed then return true end
    self.removed=true;self.state="removed"
    if raw and type(raw.remove)=="function" then return raw:remove(reason) end
    if raw and type(raw.release)=="function" then return raw:release() end
    return true
  end
  function A:release() return self:remove("release") end
  return A
end

local function compositeKey(candidates)
  local parts={}
  for _,entry in ipairs(candidates or {}) do
    local api=entry.api or entry[1]
    local h=entry.handle or entry[2]
    parts[#parts+1]=tostring(h and h.id or "?").."@"..tostring(api)
  end
  return table.concat(parts,"|")
end

function M.composeActorProviders(candidates)
  if type(candidates)~="table" or #candidates==0 then return nil end
  if #candidates==1 then return candidates[1].api or candidates[1][1] end
  local key=compositeKey(candidates)
  local cached=compositeCache[key]
  if cached then return cached end
  local renderState={vp=nil,opts=nil}
  local service={version=1,portable=true,priority=1000000,worldUnits=false,_composite=true}
  service.providers=candidates
  function service.selected(context) return true end
  function service.available(source,dex)
    for _,entry in ipairs(candidates) do
      local api=entry.api or entry[1]
      local ok=true
      if type(api.available)=="function" then
        local pok,value=pcall(api.available,source,dex);ok=pok and value~=false
      end
      if ok then return true end
    end
    return false
  end
  function service.acquire(source,dex,variant,opts)
    local errors={}
    for _,entry in ipairs(candidates) do
      local api=entry.api or entry[1]
      local h=entry.handle or entry[2]
      local available=true
      if type(api.available)=="function" then
        local ok,value=pcall(api.available,source,dex)
        available=ok and value~=false
        if not ok then errors[#errors+1]=tostring(h and h.id or "provider").." availability: "..tostring(value) end
      end
      if available then
        local ok,actor,err=pcall(api.acquire,source,dex,variant,opts)
        if ok and actor then
          return bindLayeredActor(actor,api,h and h.id or "provider",renderState)
        end
        errors[#errors+1]=tostring(h and h.id or "provider")..": "..tostring(ok and err or actor)
      end
    end
    return nil,(#errors>0 and table.concat(errors," | ") or "no actor provider has species "..tostring(dex))
  end
  function service.withRenderer(vp,callback,opts)
    local oldVP,oldOpts=renderState.vp,renderState.opts
    renderState.vp,renderState.opts=vp,opts
    local ok,a,b=pcall(callback)
    renderState.vp,renderState.opts=oldVP,oldOpts
    if not ok then return false,a end
    return a,b
  end
  function service.status()
    local ids={}
    for _,entry in ipairs(candidates) do
      local h=entry.handle or entry[2];ids[#ids+1]=h and h.id or "provider"
    end
    return {ready=true,composite=true,providers=ids}
  end
  compositeCache[key]=service
  return service
end

function M.registerModelProvider(owner,provider)
  local csm=V.CurrentSpriteModels
  if not (csm and type(csm.registerCapability)=="function") then return false,"battle actor registry unavailable" end
  local service,err=M.wrapModelProvider(provider,owner)
  if not service then return false,err end
  return csm.registerCapability(owner,"battleActors",service)
end
function M.unregisterModelProvider(owner)
  local csm=V.CurrentSpriteModels
  return csm and type(csm.unregisterCapability)=="function" and csm.unregisterCapability(owner,"battleActors") or false
end

function M.registerMoveFXProvider(owner,provider)
  local assets=V.BattleAssetProvider
  if not (assets and type(assets.register)=="function") then return false,"move/VFX registry unavailable" end
  return assets.register(owner,provider)
end
function M.unregisterMoveFXProvider(owner)
  local assets=V.BattleAssetProvider
  return assets and type(assets.unregister)=="function" and assets.unregister(owner) or false
end

function M.registerMoveBehaviorProvider(owner,provider)
  local behavior=V.MoveBehaviorProvider
  if not (behavior and type(behavior.register)=="function") then return false,"move behavior registry unavailable" end
  return behavior.register(owner,provider)
end
function M.unregisterMoveBehaviorProvider(owner)
  local behavior=V.MoveBehaviorProvider
  return behavior and type(behavior.unregister)=="function" and behavior.unregister(owner) or false
end

function M.status(context)
  local out={version=M.version}
  if V.BattleAssetProvider and type(V.BattleAssetProvider.status)=="function" then out.moveFX=V.BattleAssetProvider.status(context) end
  if V.MoveBehaviorProvider and type(V.MoveBehaviorProvider.status)=="function" then out.moveBehavior=V.MoveBehaviorProvider.status(context) end
  if V.CurrentSpriteModels and type(V.CurrentSpriteModels.status)=="function" then
    local s=V.CurrentSpriteModels.status()
    out.actorOwner=s and s.actorOwner or nil
    out.registeredActorOwners=s and s.registeredActorOwners or nil
  end
  return out
end

return M
