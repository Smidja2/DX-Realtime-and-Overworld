-- Portable battle move/VFX discovery for 368RealtimeBattleDX.
--
-- Providers are layered per move. A partial custom VFX pack may handle only a
-- few moves and transparently fall through to another provider (including XD)
-- for everything else.
local V=...
local M={version=1}
local ModLookup=V.ModLookup
local OWNER=(V.mod and V.mod.id) or "XD_BATTLE_ENVIRONMENTS"
local registered={}
local facadeCache={}

local function selected(api,context)
  if type(api.selected)~="function" then return true end
  local ok,value=pcall(api.selected,context)
  return ok and value~=false
end

local function validMoveFX(api)
  return type(api)=="table"
    and (api.version==nil or tonumber(api.version)==1)
    and (type(api.vfxForMove)=="function" or type(api.resolveMoveId)=="function")
end

local function legacyXD()
  if ModLookup and type(ModLookup.find)=="function" then
    local h=ModLookup.find(V.mod,"POKEMON_XD_GEN1")
    local e=h and h.exports
    local api=e and (e.pokemon_xd_386 or e.stadiumdx)
    if type(api)=="table" then return api,h end
  end
  local api=rawget(_G,"POKEMON_XD_386_API") or rawget(_G,"POKEMON_XD_API")
  if type(api)=="table" then return api,{id="POKEMON_XD_GEN1",exports={}} end
  return nil,nil
end

local function candidates(context)
  local game=(context and context.game) or (context and context.battle and context.battle.game)
  local rows,seen={},{ }
  local function add(api,handle,priority)
    if not (validMoveFX(api) and selected(api,context)) or seen[api] then return end
    seen[api]=true
    rows[#rows+1]={api=api,handle=handle or {id="provider",exports={}},priority=priority or tonumber(api.priority) or 0}
  end
  local handles=ModLookup and type(ModLookup.each)=="function" and ModLookup.each(V.mod,game) or {}
  for _,handle in ipairs(handles) do
    if handle and handle.id~=OWNER then
      local exports=handle.exports or {}
      add(exports.battleMoveFX or exports.battleMoveProvider,handle)
    end
  end
  for owner,api in pairs(registered) do add(api,{id=owner,exports={}}) end
  local xd,xh=legacyXD()
  if xd and not seen[xd] then add(xd,xh,-1000000) end
  table.sort(rows,function(a,b)
    if a.priority~=b.priority then return a.priority>b.priority end
    return tostring(a.handle.id)<tostring(b.handle.id)
  end)
  return rows
end

local function candidateKey(rows)
  local out={}
  for _,r in ipairs(rows) do out[#out+1]=tostring(r.handle.id).."@"..tostring(r.api) end
  return table.concat(out,"|")
end

local function markRefs(ownerMap,vfx,api)
  if type(vfx)~="table" then return end
  ownerMap[vfx]=api
  for _,key in ipairs({"attack","damage","special","start","impact","endFx","effect"}) do
    local ref=vfx[key]
    if type(ref)=="table" then ownerMap[ref]=api end
  end
end

local function facade(rows)
  if #rows==0 then return nil,nil end
  if #rows==1 then return rows[1].api,rows[1].handle end
  local key=candidateKey(rows)
  local cached=facadeCache[key]
  if cached then return cached.api,cached.handle end
  local refOwners=setmetatable({},{__mode="k"})
  local api={version=1,priority=1000000,_composite=true}
  function api.resolveMoveId(moveId)
    for _,row in ipairs(rows) do
      local p=row.api
      if type(p.hasMove)=="function" then
        local ok,has=pcall(p.hasMove,moveId);if ok and has==false then goto continue end
      end
      if type(p.resolveMoveId)=="function" then
        local ok,a,b=pcall(p.resolveMoveId,moveId)
        if ok and (a~=nil or b~=nil) then return a,b end
      end
      ::continue::
    end
    return nil,nil
  end
  function api.vfxForMove(moveId)
    for _,row in ipairs(rows) do
      local p=row.api
      if type(p.hasMove)=="function" then
        local ok,has=pcall(p.hasMove,moveId);if ok and has==false then goto continue end
      end
      if type(p.vfxForMove)=="function" then
        local ok,a,b,c=pcall(p.vfxForMove,moveId)
        if ok and a~=nil then markRefs(refOwners,a,p);return a,b,c end
      end
      ::continue::
    end
    return nil,nil,nil
  end
  function api.readVFX(ref)
    local owner=type(ref)=="table" and refOwners[ref] or nil
    if owner and type(owner.readVFX)=="function" then
      local ok,data=pcall(owner.readVFX,ref);if ok and data~=nil then return data end
    end
    for _,row in ipairs(rows) do
      local p=row.api
      if p~=owner and type(p.readVFX)=="function" then
        local ok,data=pcall(p.readVFX,ref);if ok and data~=nil then return data end
      end
    end
    return nil
  end
  function api.status()
    local ids={};for _,r in ipairs(rows) do ids[#ids+1]=r.handle.id end
    return {ready=true,composite=true,providers=ids}
  end
  local ids={};for _,r in ipairs(rows) do ids[#ids+1]=tostring(r.handle.id) end
  local handle={id="composite:"..table.concat(ids,"+"),exports={}}
  facadeCache[key]={api=api,handle=handle}
  return api,handle
end

function M.register(owner,api)
  owner=tostring(owner or "")
  if owner=="" or owner==OWNER then return false,"invalid move/VFX provider owner" end
  if not validMoveFX(api) then return false,"invalid battleMoveFX v1 provider" end
  registered[owner]=api
  return true
end

function M.unregister(owner)
  owner=tostring(owner or "")
  local had=registered[owner]~=nil
  registered[owner]=nil
  return had
end

function M.moveFX(context)
  return facade(candidates(context))
end

function M.status(context)
  local rows=candidates(context)
  local api,handle=facade(rows)
  local owners={}
  for owner in pairs(registered) do owners[#owners+1]=owner end
  table.sort(owners)
  local providers={};for _,r in ipairs(rows) do providers[#providers+1]=r.handle.id end
  return {ready=api~=nil,provider=handle and handle.id or nil,providers=providers,registeredOwners=owners}
end

return M
