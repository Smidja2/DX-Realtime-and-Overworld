local V=...
local R={installed=false,activeBattle=nil,pendingEnd=nil,finishWrapper=nil,
  rawInputCaptureInstalled=false,rawKeyPressedInner=nil,rawKeyReleasedInner=nil,
  rawGamepadPressedInner=nil,rawGamepadReleasedInner=nil,
  realtimeKeyPressed={},realtimeKeyDown={},realtimeWheelY=0,rawWheelMovedInner=nil,
  realtimeMouseDX=0,realtimeMouseDY=0,rawMouseMovedInner=nil,
  captureSoundWrapper=nil,captureSoundInner=nil,captureSoundBridge=false,nativeCaughtSuppressed=0,
  movePlayWrapper=nil,movePlayInner=nil,stereoWrapper=nil,stereoInner=nil,moveSoundBridge=false,nativeMoveSoundsSuppressed=0,
  modelPrewarm=nil,entryTiming=nil,exitTiming=nil,
  queueAdvanceWrapper=nil,queueAdvanceInner=nil,queueAdvanceBridge=false,
  nativeFxBridge=false,nativeFxDrawWrapper=nil,nativeFxDrawInner=nil,
  nativeTopDrawWrapper=nil,nativeTopDrawInner=nil,
  nativeBgpWrapper=nil,nativeBgpInner=nil,
  nativeAnimEffectWrapper=nil,nativeAnimEffectInner=nil,
  nativeHitFxWrapper=nil,nativeHitFxInner=nil,
  nativeUpdateFxWrapper=nil,nativeUpdateFxInner=nil,
  trainerItemBridge=false,trainerItemWrapper=nil,trainerItemInner=nil,
  trainerReplacementBridge=false,enemyMonFaintedWrapper=nil,enemyMonFaintedInner=nil,
  realtimeQueueUiBridge=false,statBoxAutoDismissed=0,trainerChoiceAutoDeclined=0,nativeModalName=nil,
  hardMenuQuarantine=false,nativeBattleUpdateWrapper=nil,nativeBattleUpdateInner=nil}

local mod=V.mod
local ArenaCatalog=V.ArenaCatalog
local Arena=V.Arena
local BattleArtBridge=V.BattleArtBridge
local Camera=V.Camera
local CurrentSpriteModels=V.CurrentSpriteModels
local PokemonActors=V.PokemonActors
local NativeTrainerSprites=V.NativeTrainerSprites
local PlayerTrainer=V.PlayerTrainer
local StandaloneHost=V.StandaloneHost
local BattleSettings=V.BattleSettings
local StadiumBridge=V.StadiumBridge
local Trainer=V.Trainer
local Compat=V.GenerationCompat
local BattleDirector=V.BattleDirector
local MoveFXOwnership=V.MoveFXOwnership
local BattleSides=V.BattleSides
local WazaHandlers=V.WazaHandlers
local MoveFXExtractor=V.MoveFXExtractor

local function platformOS()
  if love and love.system and type(love.system.getOS)=="function" then
    local ok,v=pcall(love.system.getOS);if ok and v then return tostring(v) end
  end
  return "Unknown"
end
local ANDROID_RUNTIME=platformOS()=="Android"
local androidActionWarmNextAt=0
local androidGcNextAt=0
local function wallNow()
  if love and love.timer and type(love.timer.getTime)=="function" then
    local ok,v=pcall(love.timer.getTime);if ok and type(v)=="number" then return v end
  end
  return os.clock()
end
local function stackTop(game)
  local stack=game and game.stack
  if stack and type(stack.top)=="function" then
    local ok,v=pcall(stack.top,stack);if ok then return v end
  end
  return nil
end

local SEMANTIC_EVENTS={
  "battle.turn_started",
  "battle.move_used",
  "battle.damage_dealt",
  "battle.status_inflicted",
  "battle.ball_thrown",
  "battle.battler_switched",
  "battle.fainted",
  "battle.exp_gained",
  "battle.turn_ended",
}

local NATIVE_BATTLE_INPUT_BLOCK={
  a=true,b=true,start=true,select=true,
  up=true,down=true,left=true,right=true,
  l=true,r=true,x=true,y=true,
  confirm=true,cancel=true,menu=true,
}

local function realtimeOwnsBattleInput(game)
  if not R.activeBattle then return false end
  if stackTop(game)~=R.activeBattle then return false end
  if BattleSettings and type(BattleSettings.realtimeEnabled)=="function" then
    local ok,v=pcall(BattleSettings.realtimeEnabled,game)
    return ok and v==true
  end
  return false
end

local function realtimeAutoAdvances(game)
  -- In realtime mode the native battle textbox is hidden, so *all* ordinary
  -- BattleState message pages must advance without a physical A/B press, not
  -- only the pages emitted by one realtime move resolution.  This remains
  -- safe for real choices: ChoiceBox/PartyMenu are pushed above BattleState,
  -- which makes realtimeOwnsBattleInput() false until that UI closes.
  return realtimeOwnsBattleInput(game)
    and R.activeBattle and R.activeBattle.phase=="messages"
end

-- Realtime owns the visible 3D battlefield. The stock BattleState still updates
-- its move-animation FX for battle semantics/timing, but its full-screen palette
-- flashes are a second presentation layer and visibly flash the XD arena. Keep
-- those timers running; suppress only their DRAW result while realtime is on.
local function realtimeOwnsPresentation(battle)
  if not (battle and battle==R.activeBattle) then return false end
  if BattleSettings and type(BattleSettings.realtimeEnabled)=="function" then
    local ok,v=pcall(BattleSettings.realtimeEnabled,battle.game)
    return ok and v==true
  end
  return false
end

local function neutralizeRealtimeNativeFx(battle)
  if not realtimeOwnsPresentation(battle) then return false end
  local fx=battle and battle.fx
  if type(fx)=="table" then
    -- Realtime owns the visible battlefield. Keep native battle logic/timers,
    -- but remove every stock full-field palette/flash/shake/wavy/blink visual.
    -- In particular, applyHitFx uses shakeProg for enemy damage and status
    -- moves such as Sand-Attack; on a transparent CBE layer those offsets can
    -- expose the white native field and look like a full-screen flash.
    fx.flash=0
    fx.bgp=nil;fx.bgpSeq=nil
    fx.wavy=nil
    fx.shake=0;fx.shakeProg=nil;fx.shakeX=0;fx.shakeY=0
    fx.hudShakeProg=nil;fx.hudShakeX=0
    fx.blink=nil
  end
  battle.letterboxWhite=false
  return true
end

local function installRealtimeNativeFxSuppression()
  local req=V.engineRequire or require
  local ok,BattleState=pcall(req,"src.battle.BattleState")
  if not ok or type(BattleState)~="table" then R.nativeFxBridge=false;return false end

  -- Quarantine stock AnimPlayer visual events at their source. Sounds still
  -- run, and AnimPlayer itself still advances, so authoritative battle timing
  -- is unchanged. This is stronger than merely hiding activeBgp()/fx.flash.
  if type(BattleState.applyAnimEffect)=="function" and BattleState.applyAnimEffect~=R.nativeAnimEffectWrapper then
    local inner=BattleState.applyAnimEffect
    R.nativeAnimEffectInner=inner
    R.nativeAnimEffectWrapper=function(self,ev,...)
      if realtimeOwnsPresentation(self) then
        local e=type(ev)=="table" and tostring(ev.effect or "") or ""
        -- SFX_* rows are sound-only; let the engine handle those normally.
        if e:match("^SFX_") then return inner(self,ev,...) end
        if type(ev)=="table" and ev.sound and type(self.playAnimSound)=="function" then
          pcall(self.playAnimSound,self,ev.sound)
        end
        neutralizeRealtimeNativeFx(self)
        return nil
      end
      return inner(self,ev,...)
    end
    BattleState.applyAnimEffect=R.nativeAnimEffectWrapper
  end

  -- The post-move applying-attack animation is a separate engine path. It is
  -- what drives enemy-hit vertical shakes and non-damaging status-move shakes.
  -- Preserve its sound + waitFrames by running it, then delete only visuals.
  if type(BattleState.applyHitFx)=="function" and BattleState.applyHitFx~=R.nativeHitFxWrapper then
    local inner=BattleState.applyHitFx
    R.nativeHitFxInner=inner
    R.nativeHitFxWrapper=function(self,hit,...)
      local result=inner(self,hit,...)
      neutralizeRealtimeNativeFx(self)
      return result
    end
    BattleState.applyHitFx=R.nativeHitFxWrapper
  end

  -- Catch fallback anim.flash rows and any visual state written by queue/update
  -- code outside applyAnimEffect/applyHitFx before the next frame is drawn.
  if type(BattleState.update)=="function" and BattleState.update~=R.nativeUpdateFxWrapper then
    local inner=BattleState.update
    R.nativeUpdateFxInner=inner
    R.nativeUpdateFxWrapper=function(self,...)
      local result=inner(self,...)
      neutralizeRealtimeNativeFx(self)
      return result
    end
    BattleState.update=R.nativeUpdateFxWrapper
  end

  -- Palette/BGP flashes (SE_DARK_SCREEN_FLASH / SE_FLASH_SCREEN_LONG and
  -- related palette rows) all resolve through activeBgp(). Returning nil here
  -- leaves the native queue/timers intact while preventing the 3D arena from
  -- inheriting the Game Boy/SGB flash.
  if type(BattleState.activeBgp)=="function" and BattleState.activeBgp~=R.nativeBgpWrapper then
    local inner=BattleState.activeBgp
    R.nativeBgpInner=inner
    R.nativeBgpWrapper=function(self,...)
      if realtimeOwnsPresentation(self) then return nil end
      return inner(self,...)
    end
    BattleState.activeBgp=R.nativeBgpWrapper
  end

  -- Wide layout bypasses drawClassic() entirely, so suppress the same native
  -- white-flash flag around the top-level BattleState:draw() as well. This
  -- catches both classic and widescreen/native composition paths.
  if type(BattleState.draw)=="function" and BattleState.draw~=R.nativeTopDrawWrapper then
    local inner=BattleState.draw
    R.nativeTopDrawInner=inner
    R.nativeTopDrawWrapper=function(self,...)
      local fx=self and self.fx
      if not (fx and realtimeOwnsPresentation(self)) then return inner(self,...) end
      local saved=fx.flash
      fx.flash=0
      local out={pcall(inner,self,...)}
      fx.flash=saved
      local success=table.remove(out,1)
      if not success then error(out[1],0) end
      return (table.unpack or unpack)(out)
    end
    BattleState.draw=R.nativeTopDrawWrapper
  end

  -- Animations-off fallback uses fx.flash as a literal white fullscreen overlay
  -- at the end of drawClassic(). Temporarily zero only that draw flag. Do not
  -- erase it from state: updateFx continues to advance it normally.
  if type(BattleState.drawClassic)=="function" and BattleState.drawClassic~=R.nativeFxDrawWrapper then
    local inner=BattleState.drawClassic
    R.nativeFxDrawInner=inner
    R.nativeFxDrawWrapper=function(self,...)
      local fx=self and self.fx
      if not (fx and realtimeOwnsPresentation(self)) then return inner(self,...) end
      local saved=fx.flash
      fx.flash=0
      local out={pcall(inner,self,...)}
      fx.flash=saved
      local success=table.remove(out,1)
      if not success then error(out[1],0) end
      return (table.unpack or unpack)(out)
    end
    BattleState.drawClassic=R.nativeFxDrawWrapper
  end

  R.nativeFxBridge=(BattleState.activeBgp==R.nativeBgpWrapper)
    and (BattleState.draw==R.nativeTopDrawWrapper)
    and (BattleState.drawClassic==R.nativeFxDrawWrapper)
    and (type(BattleState.applyAnimEffect)~="function" or BattleState.applyAnimEffect==R.nativeAnimEffectWrapper)
    and (type(BattleState.applyHitFx)~="function" or BattleState.applyHitFx==R.nativeHitFxWrapper)
    and (type(BattleState.update)~="function" or BattleState.update==R.nativeUpdateFxWrapper)
  return R.nativeFxBridge
end

function R.consumeRealtimeKey(key)
  key=tostring(key or ""):lower()
  if key=="" then return false end
  local hit=R.realtimeKeyPressed[key]==true
  R.realtimeKeyPressed[key]=nil
  return hit
end

function R.realtimeKeyIsDown(key)
  return R.realtimeKeyDown[tostring(key or ""):lower()]==true
end

function R.consumeRealtimeWheel()
  local y=tonumber(R.realtimeWheelY) or 0
  R.realtimeWheelY=0
  return y
end

function R.consumeRealtimeMouse()
  local dx=tonumber(R.realtimeMouseDX) or 0
  local dy=tonumber(R.realtimeMouseDY) or 0
  R.realtimeMouseDX,R.realtimeMouseDY=0,0
  return dx,dy
end

local function latchRealtimeKeyPressed(key)
  key=tostring(key or ""):lower()
  if key=="" then return end
  if not R.realtimeKeyDown[key] then
    R.realtimeKeyPressed[key]=true
  end
  R.realtimeKeyDown[key]=true
end

local function latchRealtimeKeyReleased(key)
  key=tostring(key or ""):lower()
  if key=="" then return end
  R.realtimeKeyDown[key]=nil
end

local function installRawRealtimeInputCapture()
  if R.rawInputCaptureInstalled then return true end

  local req=V.engineRequire or require
  local ok,Game=pcall(req,"src.core.Game")
  if not ok or type(Game)~="table" then return false end

  -- Hard realtime keyboard ownership.
  --
  -- Gen1Recomp converts keyboard keys into its virtual pad inside
  -- Game:keypressed/keyreleased, before input.step. Therefore masking only
  -- game.input during input.step is too late: the invisible command cursor can
  -- already have moved or confirmed FIGHT / ITEM / PKMN / RUN.
  --
  -- While REALTIME owns the top BattleState we swallow every keyboard key that
  -- can reasonably navigate/confirm/cancel the native battle command menu.
  -- RealtimeBattle still reads love.keyboard directly, so WASD and the future
  -- 6/7/8/9 move hotkeys remain available to the realtime controller.
  local REALTIME_RAW_KEYS={
    space=true,["return"]=true,kpenter=true,
    up=true,down=true,left=true,right=true,
    w=true,a=true,s=true,d=true,
    z=true,x=true,c=true,v=true,lctrl=true,
    j=true,k=true,l=true,
    backspace=true,
    ["0"]=true,["6"]=true,["7"]=true,["8"]=true,["9"]=true,
    kp9=true,kp6=true,kp3=true,["kp."]=true,
  }
  local function blocksRealtimeKey(key)
    return REALTIME_RAW_KEYS[tostring(key):lower()]==true
  end

  if type(Game.keypressed)=="function" then
    local inner=Game.keypressed
    R.rawKeyPressedInner=inner
    Game.keypressed=function(self,key,...)
      if realtimeOwnsBattleInput(self) and blocksRealtimeKey(key) then
        latchRealtimeKeyPressed(key)
        return
      end
      return inner(self,key,...)
    end
  end

  if type(Game.keyreleased)=="function" then
    local inner=Game.keyreleased
    R.rawKeyReleasedInner=inner
    Game.keyreleased=function(self,key,...)
      if realtimeOwnsBattleInput(self) and blocksRealtimeKey(key) then
        latchRealtimeKeyReleased(key)
        return
      end
      return inner(self,key,...)
    end
  end

  -- Same isolation for controller virtual-pad inputs. The realtime prototype
  -- can later read raw joystick state directly without feeding the native menu.
  local REALTIME_PAD_BUTTONS={
    a=true,b=true,x=true,y=true,start=true,back=true,
    dpup=true,dpdown=true,dpleft=true,dpright=true,
    leftshoulder=true,rightshoulder=true,
  }
  local function blocksRealtimePad(button)
    return REALTIME_PAD_BUTTONS[tostring(button):lower()]==true
  end

  if type(Game.gamepadpressed)=="function" then
    local inner=Game.gamepadpressed
    R.rawGamepadPressedInner=inner
    Game.gamepadpressed=function(self,joystick,button,...)
      if realtimeOwnsBattleInput(self) and blocksRealtimePad(button) then
        return
      end
      return inner(self,joystick,button,...)
    end
  end

  if type(Game.gamepadreleased)=="function" then
    local inner=Game.gamepadreleased
    R.rawGamepadReleasedInner=inner
    Game.gamepadreleased=function(self,joystick,button,...)
      if realtimeOwnsBattleInput(self) and blocksRealtimePad(button) then
        return
      end
      return inner(self,joystick,button,...)
    end
  end

  -- Mouse wheel owns realtime camera distance while the realtime BattleState is
  -- top-most. LÖVE dispatches wheel events through love.wheelmoved; preserve
  -- the previous callback outside realtime battles.
  if love then
    local inner=love.wheelmoved
    R.rawWheelMovedInner=inner
    love.wheelmoved=function(x,y)
      if realtimeOwnsBattleInput(mod and mod.game) then
        R.realtimeWheelY=(tonumber(R.realtimeWheelY) or 0)+(tonumber(y) or 0)
        return
      end
      if type(inner)=="function" then return inner(x,y) end
    end
  end

  -- Captured relative mouse movement for the battle third-person controller.
  if love then
    local inner=love.mousemoved
    R.rawMouseMovedInner=inner
    love.mousemoved=function(x,y,dx,dy,istouch)
      if realtimeOwnsBattleInput(mod and mod.game) then
        R.realtimeMouseDX=(tonumber(R.realtimeMouseDX) or 0)+(tonumber(dx) or 0)
        R.realtimeMouseDY=(tonumber(R.realtimeMouseDY) or 0)+(tonumber(dy) or 0)
        return
      end
      if type(inner)=="function" then return inner(x,y,dx,dy,istouch) end
    end
  end

  R.rawInputCaptureInstalled=true
  return true
end

-- Realtime combat owns its own visible HUD, so no ordinary BattleState text
-- page may leave an invisible PromptText/CONT gate waiting for a physical A/B
-- press.  Auto-confirm the text layer for the entire realtime BattleState,
-- including faint/EXP/victory/return-to-map cleanup.  Queue waits, animations,
-- HP drain and sounds still run normally.  Real ChoiceBox/PartyMenu states are
-- pushed above BattleState and therefore temporarily disable this bridge.
local function installRealtimeMessageAdvanceBridge()
  local req=V.engineRequire or require
  local ok,BattleState=pcall(req,"src.battle.BattleState")
  if not ok or type(BattleState)~="table" or type(BattleState.updateQueue)~="function" then
    R.queueAdvanceBridge=false
    return false
  end
  if BattleState.updateQueue==R.queueAdvanceWrapper then
    R.queueAdvanceBridge=true
    return true
  end
  local inner=BattleState.updateQueue
  R.queueAdvanceInner=inner
  R.queueAdvanceWrapper=function(self,...)
    local own=self==R.activeBattle and realtimeAutoAdvances(self.game)
    if not own then return inner(self,...) end

    -- A realtime XD faint tail is presentation that must finish before the
    -- authoritative queue is allowed to replace the battler. This is especially
    -- important in multi-Pokemon trainer battles where the next send-out can
    -- otherwise retire the KO'd 3D actor before its faint clip becomes visible.
    local rt=V and V.RealtimeBattle
    -- Mirror the exact authoritative battle text before this hidden native
    -- message page is auto-advanced. RealtimeBattle decides which acting
    -- side owns it and filters duplicate move/faint/EXP lines.
    local textRow=self.current
    if not (type(textRow)=="table" and textRow.text~=nil) then
      textRow=type(self.queue)=="table" and self.queue[1] or nil
    end
    if rt and type(rt.captureNativeText)=="function" and type(textRow)=="table" and textRow.text~=nil
       and not textRow.__xdRealtimeTextCaptured then
      textRow.__xdRealtimeTextCaptured=true
      pcall(rt.captureNativeText,rt,self,textRow)
    end
    if rt and type(rt.queuePresentationHold)=="function" then
      local okHold,hold=pcall(rt.queuePresentationHold,rt,self)
      if okHold and hold==true then return true end
    end

    local input=self.game and self.game.input
    if type(input)~="table" then return inner(self,...) end
    local oldPressed=input.wasPressed
    local oldDown=input.isDown

    input.wasPressed=function(obj,key,...)
      local k=tostring(key or ""):lower()
      if k=="a" or k=="b" then return true end
      if type(oldPressed)=="function" then return oldPressed(obj,key,...) end
      return false
    end
    input.isDown=function(obj,key,...)
      local k=tostring(key or ""):lower()
      if k=="a" or k=="b" then return true end
      if type(oldDown)=="function" then return oldDown(obj,key,...) end
      return false
    end

    -- These are message-only waits. Do not touch queue waitFrames, animation,
    -- HP-drain, sound, or UI waits: those still carry real battle semantics.
    if self.msgPreWait then self.msgPreWait=0 end
    if self.msgPromptWait then self.msgPromptWait=0 end
    if self.msgAutoWait then self.msgAutoWait=0 end
    if self.current and self.codes then
      self.charTimer=math.max(tonumber(self.charTimer) or 0,65536)
    end

    local result={pcall(inner,self,...)}
    input.wasPressed=oldPressed
    input.isDown=oldDown
    local success=table.remove(result,1)
    if not success then error(result[1],0) end
    return (table.unpack or unpack)(result)
  end
  BattleState.updateQueue=R.queueAdvanceWrapper
  R.queueAdvanceBridge=true
  return true
end

local function callEngineStepWithRealtimeInputBlocked(next,game,dt)
  if not realtimeOwnsBattleInput(game) then
    return next(game,dt)
  end

  local input=game and game.input
  if type(input)~="table" then
    return next(game,dt)
  end

  local originalWasPressed=input.wasPressed
  local originalIsDown=input.isDown
  local originalWasReleased=input.wasReleased

  -- The engine battle state reads semantic pad actions from game.input.  Mask
  -- those only while the engine advances.  Our real-time controller reads raw
  -- LÖVE keyboard state after this step, so Space/WASD still belong to it.
  if type(originalWasPressed)=="function" then
    input.wasPressed=function(self,key,...)
      local k=tostring(key):lower()
      if realtimeAutoAdvances(game) and (k=="a" or k=="b") then return true end
      if NATIVE_BATTLE_INPUT_BLOCK[k] then return false end
      return originalWasPressed(self,key,...)
    end
  end
  if type(originalIsDown)=="function" then
    input.isDown=function(self,key,...)
      local k=tostring(key):lower()
      if realtimeAutoAdvances(game) and (k=="a" or k=="b") then return true end
      if NATIVE_BATTLE_INPUT_BLOCK[k] then return false end
      return originalIsDown(self,key,...)
    end
  end
  if type(originalWasReleased)=="function" then
    input.wasReleased=function(self,key,...)
      if NATIVE_BATTLE_INPUT_BLOCK[tostring(key):lower()] then return false end
      return originalWasReleased(self,key,...)
    end
  end

  local results={pcall(next,game,dt)}

  input.wasPressed=originalWasPressed
  input.isDown=originalIsDown
  input.wasReleased=originalWasReleased

  local ok=table.remove(results,1)
  if not ok then error(results[1],0) end
  return (table.unpack or unpack)(results)
end

local function contextFor(battle)
  battle=Compat and Compat.prepare(battle) or battle
  return {battle=battle,game=(battle and battle.game) or mod.game}
end


local unpackArgs=table.unpack or unpack
local function installCaptureSoundBridge()
  local req=V.engineRequire or require
  local ok,Sound=pcall(req,"src.core.Sound")
  if not ok or type(Sound)~="table" or type(Sound.play)~="function" then
    R.captureSoundBridge=false
    return false
  end
  if Sound.play==R.captureSoundWrapper then R.captureSoundBridge=true;return true end
  local inner=Sound.play
  R.captureSoundInner=inner
  R.captureSoundWrapper=function(...)
    local args={...}
    local requested
    -- Current Gen1Recomp calls Sound.play(data,"Caught_Mon"), but keep the
    -- bridge tolerant of a future method-style call without intercepting any
    -- unrelated sound identifier.
    for i=1,math.min(3,#args) do
      if type(args[i])=="string" and args[i]=="Caught_Mon" then requested=args[i];break end
    end
    if requested=="Caught_Mon" and R.activeBattle and PlayerTrainer
        and type(PlayerTrainer.suppressesNativeCaughtAudio)=="function" then
      local okOwn,owned=pcall(PlayerTrainer.suppressesNativeCaughtAudio,PlayerTrainer,contextFor(R.activeBattle))
      if okOwn and owned==true then
        R.nativeCaughtSuppressed=(tonumber(R.nativeCaughtSuppressed) or 0)+1
        -- The engine has already resolved the catch and CBE's ISO-derived
        -- me_snatch source is playing. Return no native source so sayNextWaitSfx
        -- proceeds without layering the Game Boy/GBC caught fanfare on top.
        return nil
      end
    end
    return inner(unpackArgs(args,1,#args))
  end
  Sound.play=R.captureSoundWrapper
  R.captureSoundBridge=true

  local function sourceMoveAudioOwned()
    if not (R.activeBattle and MoveFXOwnership and type(MoveFXOwnership.ownsNativeAudio)=="function") then return false end
    local okOwn,owned=pcall(MoveFXOwnership.ownsNativeAudio,MoveFXOwnership,R.activeBattle)
    return okOwn and owned==true
  end
  -- Gen I's animation sound path is Sound.playMove; Gen II's anim_sound maps
  -- directly to PlayStereoSFX / Sound.playStereo.  Keep both native paths live
  -- unless the active Waza has a complete generated GameSound set. Missing or
  -- unrenderable source ids therefore fail open with the stock GB/GBC sound.
  if type(Sound.playMove)=="function" and Sound.playMove~=R.movePlayWrapper then
    local innerMove=Sound.playMove;R.movePlayInner=innerMove
    R.movePlayWrapper=function(...)
      if sourceMoveAudioOwned() then R.nativeMoveSoundsSuppressed=(R.nativeMoveSoundsSuppressed or 0)+1;return nil end
      return innerMove(...)
    end
    Sound.playMove=R.movePlayWrapper
  end
  if type(Sound.playStereo)=="function" and Sound.playStereo~=R.stereoWrapper then
    local innerStereo=Sound.playStereo;R.stereoInner=innerStereo
    R.stereoWrapper=function(...)
      if sourceMoveAudioOwned() then R.nativeMoveSoundsSuppressed=(R.nativeMoveSoundsSuppressed or 0)+1;return nil end
      return innerStereo(...)
    end
    Sound.playStereo=R.stereoWrapper
  end
  R.moveSoundBridge=(Sound.playMove==R.movePlayWrapper) or (Sound.playStereo==R.stereoWrapper)
  return true
end

local function dispatch(name,payload)
  local battle=(type(payload)=="table" and payload.battle) or R.activeBattle
  battle=Compat and Compat.prepare(battle) or battle
  local ctx=contextFor(battle)
  -- A replacement must be resident BEFORE the presentation providers observe
  -- the switch. Otherwise a large HSD body can spend the first visible switch
  -- frames parsing packed vertices/uploading meshes and pop in late. This gate
  -- is presentation-only and never changes the battle model or switch result.
  if name=="battle.battler_switched" and PokemonActors and type(PokemonActors.prewarmSwitch)=="function" then
    local side
    if BattleSides and type(BattleSides.payload)=="function" then
      local okSide,value=pcall(BattleSides.payload,ctx,payload,{"side","battler","replacement","newBattler","target"})
      if okSide then side=value end
    end
    if not side and type(payload)=="table" then side=payload.side or payload.targetSide end
    if BattleSides and type(BattleSides.value)=="function" then side=BattleSides.value(side) or side end
    local replacement=type(payload)=="table" and (payload.replacement or payload.newBattler or payload.battler or payload.target) or nil
    if side then pcall(PokemonActors.prewarmSwitch,battle,side,replacement) end
  end
  if BattleDirector and type(BattleDirector.event)=="function" then
    pcall(BattleDirector.event,BattleDirector,ctx,name,payload)
  end
  if MoveFXOwnership and type(MoveFXOwnership.event)=="function" then
    pcall(MoveFXOwnership.event,MoveFXOwnership,ctx,name,payload)
  end
  if StandaloneHost then StandaloneHost.event(name,payload) end

  -- StandaloneHost forwards events into the actor host using its rich arena
  -- context. When Stadium owns the compositor there is no standalone session,
  -- so route the same authoritative event directly. This keeps CBE's portable
  -- actor lifecycle aligned in both hosts without touching battle logic.
  local standaloneActive=false
  if StandaloneHost and type(StandaloneHost.status)=="function" then
    local ok,status=pcall(StandaloneHost.status)
    standaloneActive=ok and type(status)=="table" and status.active==true
  end
  if not standaloneActive and CurrentSpriteModels and type(CurrentSpriteModels.event)=="function" then
    pcall(CurrentSpriteModels.event,CurrentSpriteModels,ctx,name,payload)
  end

  -- Realtime hit-stop must be keyed to the authoritative damage boundary, not
  -- only to an immediate HP delta after executeAction(). Some engine paths apply
  -- damage through their queued semantic event, so let RealtimeBattle observe the
  -- same battle.damage_dealt event that drives the 3D actor's hurt animation.
  local rt=V and V.RealtimeBattle
  if rt and type(rt.event)=="function" then pcall(rt.event,rt,ctx,name,payload) end

  -- StadiumBattleFX API v1 does not forward battle.ball_thrown to external
  -- camera providers. Bridge only that missing engine event, and only when CBE
  -- is the camera provider selected for this battle.
  if name=="battle.ball_thrown" and Camera and StadiumBridge and StadiumBridge.usesCamera(battle) then
    pcall(Camera.event,Camera,ctx,name,payload)
  end

  if PlayerTrainer and type(PlayerTrainer.event)=="function" then PlayerTrainer:event(ctx,name,payload) end
  if Trainer and type(Trainer.event)=="function" then Trainer:event(ctx,name,payload) end
end

-- Gen1 has no semantic battle.item_used event for trainer AI items. Bridge the
-- exact TrainerAI.useItem call into the same presentation event stream so the
-- realtime top action box can report Potion/Full Heal/etc. without restoring
-- the hidden native textbox. This is observation only; the original function
-- remains authoritative for all item effects and messages.
local function installTrainerItemActionBridge()
  local req=V.engineRequire or require
  local ok,TrainerAI=pcall(req,"src.battle.TrainerAI")
  if not ok or type(TrainerAI)~="table" or type(TrainerAI.useItem)~="function" then
    R.trainerItemBridge=false;return false
  end
  if TrainerAI.useItem==R.trainerItemWrapper then R.trainerItemBridge=true;return true end
  local inner=TrainerAI.useItem
  R.trainerItemInner=inner
  R.trainerItemWrapper=function(battle,item,...)
    if battle and battle==R.activeBattle then
      dispatch("battle.trainer_item_used",{battle=battle,item=item,trainer=battle.trainer})
    end
    return inner(battle,item,...)
  end
  TrainerAI.useItem=R.trainerItemWrapper
  R.trainerItemBridge=true
  return true
end

local function beginBattle(payload)
  local battle=type(payload)=="table" and payload.battle or nil
  battle=Compat and Compat.prepare(battle) or battle
  if not battle then return end
  local entryStart=wallNow()
  -- Gen1Recomp can recycle the same battle table between encounters.  Clear
  -- any previous arena binding on the authoritative battle.started boundary,
  -- not only on battle.ended, so a missed/late end event can never carry Mt.
  -- Battle (or any other arena) into the user's next explicit selection.
  if ArenaCatalog and ArenaCatalog.releaseBattle then ArenaCatalog.releaseBattle() end
  R.activeBattle=battle
  R.pendingEnd=nil
  if ANDROID_RUNTIME then androidActionWarmNextAt=wallNow() end
  -- Reclaim this narrow audio seam at the authoritative battle boundary in
  -- case another mod rewrapped Sound.play after mods.loaded.
  installCaptureSoundBridge()
  if BattleDirector and type(BattleDirector.begin)=="function" then
    pcall(BattleDirector.begin,BattleDirector,contextFor(battle))
  end
  if MoveFXOwnership and type(MoveFXOwnership.begin)=="function" then
    pcall(MoveFXOwnership.begin,MoveFXOwnership,contextFor(battle))
  end

  if not StandaloneHost then return end
  if StadiumBridge and type(StadiumBridge.refreshModelGates)=="function" then
    pcall(StadiumBridge.refreshModelGates)
  end
  if BattleArtBridge and type(BattleArtBridge.install)=="function" then
    pcall(BattleArtBridge.install)
  end

  -- StadiumBattleFX 2.1.x intentionally calls BattleHost.install(true) again
  -- on battle.started. Since Stadium loads before CBE, that can move its host
  -- back OUTSIDE the wrapper CBE installed during mods.loaded. Reinstall CBE
  -- here, at the same authoritative boundary but after earlier-priority event
  -- handlers, so CBE is outermost for the actual battle. StandaloneHost uses
  -- epoch guards, therefore an older nested CBE wrapper becomes a no-op rather
  -- than drawing the arena twice.
  pcall(StandaloneHost.install,true)

  -- HARD OWNERSHIP CONTRACT:
  -- If CBE is equipped and COLOSSEUM ARENAS is enabled, CBE's local host owns
  -- the complete BattleState world/compositor on BOTH generations. Stadium,
  -- Battle Art, Dramatic Shape and any other full-stage provider are never
  -- allowed to become the battle host. They may contribute Pokemon artwork or
  -- portable battleActors through CurrentSpriteModels, but arena/camera/trainers
  -- and BattleState presentation flow remain CBE-authored without exception.
  --
  -- Older builds delegated Gen I to Stadium's provider host when present. That
  -- allowed Battle Art staging selected inside Stadium to replace the arena,
  -- which is the regression this branch removes.
  if StadiumBridge then StadiumBridge.setDelegated(false) end

  -- Model readiness is part of CBE's battle-entry contract. The old path
  -- deliberately deferred HSD scene creation until draw() to avoid a black
  -- transition stall; that traded one pause for a much worse visible late
  -- spawn on high-detail Pokemon. Prepare both active battlers and only the
  -- native action banks their current moves require before the arena opens.
  local modelStart=wallNow()
  local modelsEnabled=true
  if V.BattleSettings and type(V.BattleSettings.pokemonModelsEnabled)=="function" then
    local okEnabled,value=pcall(V.BattleSettings.pokemonModelsEnabled,battle and battle.game)
    if okEnabled then modelsEnabled=value~=false end
  end
  if modelsEnabled and PokemonActors and type(PokemonActors.prewarmBattle)=="function" then
    local okWarm,result=pcall(PokemonActors.prewarmBattle,battle)
    if okWarm then R.modelPrewarm=result else R.modelPrewarm={failed=2,error=tostring(result)} end
  else
    R.modelPrewarm={ready=0,failed=0,actions=0,environmentOnly=true}
  end
  local modelEnd=wallNow()

  local hostStart=wallNow()
  local began=StandaloneHost.begin(battle)
  local hostEnd=wallNow()
  R.entryTiming={totalMs=math.max(0,(hostEnd-entryStart)*1000),modelMs=math.max(0,(modelEnd-modelStart)*1000),
    hostMs=math.max(0,(hostEnd-hostStart)*1000),began=began and true or false}
  if NativeTrainerSprites then
    if began then NativeTrainerSprites:begin({battle=battle})
    else
      -- Even a source/cache failure must not hand ownership to another battle
      -- compositor. Keep CBE's staging bridge authoritative and fail only this
      -- native trainer-picture suppression seam.
      NativeTrainerSprites:finish({battle=battle})
    end
  end
end

local function finishPresentation(battle,reason)
  local exitStart=wallNow()
  battle=Compat and Compat.prepare(battle) or battle
  local standaloneWasActive=false
  if StandaloneHost and type(StandaloneHost.status)=="function" then
    local ok,status=pcall(StandaloneHost.status)
    standaloneWasActive=ok and type(status)=="table" and status.active==true
  end
  local hostFinishStart=wallNow()
  if StandaloneHost then StandaloneHost.finish(reason or "battle.ended") end
  local hostFinishEnd=wallNow()
  -- A delegated Stadium compositor has no StandaloneHost session to own actor
  -- cleanup. Close CBE's portable actors explicitly at the same authoritative
  -- screen boundary; StandaloneHost already does this when it was active.
  if not standaloneWasActive and CurrentSpriteModels and type(CurrentSpriteModels.finish)=="function" then
    pcall(CurrentSpriteModels.finish,CurrentSpriteModels,contextFor(battle),reason or "battle.ended")
  end
  if NativeTrainerSprites then NativeTrainerSprites:finish({battle=battle}) end
  if ArenaCatalog and ArenaCatalog.releaseBattle then ArenaCatalog.releaseBattle(battle) end
  if BattleDirector and type(BattleDirector.finish)=="function" then
    pcall(BattleDirector.finish,BattleDirector,contextFor(battle),reason or "battle.ended")
  end
  if MoveFXOwnership and type(MoveFXOwnership.finish)=="function" then
    pcall(MoveFXOwnership.finish,MoveFXOwnership,contextFor(battle),reason or "battle.ended")
  end
  -- Android keeps a small runtime-ready working set instead of throwing away
  -- every parsed/uploaded actor at the end of every battle. 1.7.2's full purge
  -- protected VRAM, but it also guaranteed that the next battle/Pokemon screen
  -- paid the Lua parse + texture decode + GPU upload cost again. 1.7.10 keeps a
  -- bounded multi-battle Pokemon/Waza working set and only evicts after its soft
  -- cap is exceeded; compact parsed MoveFX specs remain cached on disk/in Lua.
  local pokemonTrimMs,wazaTrimMs,randomPrimeMs=0,0,0
  if ANDROID_RUNTIME then
    if PokemonActors and type(PokemonActors.trimRuntimeMemory)=="function" then
      local t0=wallNow()
      -- Keep a bounded eight-species working set. Nothing is released while
      -- residency is <=8, eliminating the battle-end eviction/reload cycle that
      -- was still visible as occasional route-to-route stutter in 1.7.9. Once
      -- above the cap, four party priorities + four recent species win the LRU.
      pcall(PokemonActors.trimRuntimeMemory,{game=battle and battle.game,keepParty=4,keepRecent=4,softLimit=8})
      pokemonTrimMs=math.max(0,(wallNow()-t0)*1000)
    end
    -- Do not enqueue model materialization back into ordinary overworld input
    -- frames. An encounter can be accepted inside input.step, so any expensive
    -- work after the engine step can delay the FIRST transition frame by
    -- seconds. Missing party bodies are cheap runtime-sidecar reloads at the
    -- next explicit readiness boundary instead.
    if WazaHandlers and type(WazaHandlers.trimRuntimeMemory)=="function" then
      local t0=wallNow();pcall(WazaHandlers.trimRuntimeMemory);wazaTrimMs=math.max(0,(wallNow()-t0)*1000)
    end
    -- Do NOT clear MoveFXExtractor.memory here. Those entries are compact
    -- parsed cache metadata and prevent repeated disk Lua parsing; WazaHandlers
    -- owns/reclaims the heavyweight GPU-side effect resources above.
    -- Full collections here created a stop-the-world pause immediately before
    -- the next menu/battle. GPU objects are explicitly released above; Lua heap
    -- cleanup is stepped incrementally by the non-battle input hook.
  end

  -- RANDOM still chooses its next venue immediately, but 1.7.10 deliberately
  -- does NOT materialize that arena synchronously on the battle-exit seam.
  -- 1.7.9 moved cold work away from entry but could simply turn it into an
  -- equally visible hitch while returning to the overworld. Runtime mesh
  -- sidecars remain persistent, and already-resident arenas stay hot; a truly
  -- cold random venue is paid behind its next transition instead of freezing
  -- the previous battle's exit.
  local game=battle and battle.game
  if game and ArenaCatalog and type(ArenaCatalog.selected)=="function" and ArenaCatalog.selected(game)=="random"
      and type(ArenaCatalog.primeRandom)=="function" then
    local t0=wallNow();pcall(ArenaCatalog.primeRandom,game);randomPrimeMs=math.max(0,(wallNow()-t0)*1000)
  end
  R.exitTiming={totalMs=math.max(0,(wallNow()-exitStart)*1000),hostFinishMs=math.max(0,(hostFinishEnd-hostFinishStart)*1000),
    pokemonTrimMs=pokemonTrimMs,wazaTrimMs=wazaTrimMs,randomPrimeMs=randomPrimeMs}
  R.activeBattle=nil
  R.pendingEnd=nil
end

local function endBattle(payload)
  dispatch("battle.ended",payload)
  local battle=(type(payload)=="table" and payload.battle) or R.activeBattle
  battle=Compat and Compat.prepare(battle) or battle
  -- Both supported BattleState implementations can announce battle.ended
  -- before their authoritative tail has consumed the killing faint, EXP,
  -- money/victory pages and final return-to-map boundary.  Do not tear the XD
  -- presentation down on that early semantic event.  Keep it alive until
  -- BattleState:finishBattle is actually reached.
  R.pendingEnd=battle
  if not R.finishBoundaryInstalled then
    -- Compatibility fallback for an engine build without finishBattle.  The
    -- normal supported builds install the finish boundary below; this avoids a
    -- permanently resident presentation on an unknown host.
    finishPresentation(battle,"battle.ended.no-finish-boundary")
  end
end

local function installFinishBoundary()
  local req=V.engineRequire or require
  local ok,BattleState=pcall(req,"src.battle.BattleState")
  if not ok or type(BattleState)~="table" or type(BattleState.finishBattle)~="function" then
    R.finishBoundaryInstalled=false
    return false
  end
  if BattleState.finishBattle==R.finishWrapper then
    R.finishBoundaryInstalled=true
    return true
  end
  local inner=BattleState.finishBattle
  R.finishWrapper=function(self,...)
    local results={pcall(inner,self,...)}
    local success=table.remove(results,1)
    local battle=Compat and Compat.prepare(self) or self
    local pending=R.pendingEnd
    if pending and ((Compat and Compat.matches(pending,battle)) or pending==battle) then
      finishPresentation(battle,"battle.screen.finished")
    end
    if not success then error(results[1],0) end
    return unpack(results)
  end
  BattleState.finishBattle=R.finishWrapper
  R.finishBoundaryInstalled=true
  return true
end


-- Exact BattleState-bound quarantine for the invisible native command menu.
-- The broader input.step mask remains as an outer safety net, but this wrapper
-- sits on the consumer itself so FIGHT/PKMN/ITEM/RUN cannot move or confirm
-- underneath the realtime HUD regardless of hook order or input remapping.
-- Realtime trainer battles do not expose the stock SHIFT-style YES/NO prompt.
-- BattleState:enemyMonFainted normally pauses the replacement queue on that
-- ChoiceBox before it creates the next enemy battler. Because the realtime
-- presenter owns the battle UI, that native prompt can be hidden while still
-- blocking the authoritative queue -- leaving the KO'd enemy on screen forever.
--
-- Run ONLY the trainer-replacement decision as SET style while realtime owns
-- the battle. This is deliberately scoped to the synchronous enemyMonFainted()
-- call and the save option is restored immediately, so non-realtime battles and
-- the user's persistent battle-style preference are untouched. All native
-- faint, EXP, send-out, battle.battler_switched, victory and party bookkeeping
-- still comes from BattleState itself; we merely skip the invisible free-switch
-- question that realtime currently has no UI for.
local function installRealtimeTrainerReplacementBridge()
  local req=V.engineRequire or require
  local ok,BattleState=pcall(req,"src.battle.BattleState")
  if not ok or type(BattleState)~="table" or type(BattleState.enemyMonFainted)~="function" then
    R.trainerReplacementBridge=false
    return false
  end
  if BattleState.enemyMonFainted==R.enemyMonFaintedWrapper then
    R.trainerReplacementBridge=true
    return true
  end
  local inner=BattleState.enemyMonFainted
  R.enemyMonFaintedInner=inner
  R.enemyMonFaintedWrapper=function(self,...)
    if not (self==R.activeBattle and self.kind=="trainer" and realtimeOwnsPresentation(self)) then
      return inner(self,...)
    end
    local save=self.game and self.game.save
    local opts=save and save.options
    if type(opts)~="table" then return inner(self,...) end
    local previous=opts.battleStyle
    opts.battleStyle="set"
    local out={pcall(inner,self,...)}
    opts.battleStyle=previous
    local passed=table.remove(out,1)
    if not passed then error(out[1],0) end
    return (table.unpack or unpack)(out)
  end
  BattleState.enemyMonFainted=R.enemyMonFaintedWrapper
  R.trainerReplacementBridge=true
  return true
end


-- Realtime queue UI bridge.
--
-- enemyMonFainted() awards EXP BEFORE it queues the next trainer send-out.
-- A level-up inserts BattleState.StatBox into that same queue. updateQueue()
-- then sets waitingUI and will not continue until the pushed state pops.
-- In the XD realtime presentation the battle world keeps updating behind that
-- native modal, so it looks exactly like a replacement softlock: the defeated
-- enemy stays fainted on the field while the player can still move.
--
-- StatBox is informational only (A/B simply closes it), so realtime mode may
-- safely auto-dismiss it after the engine pushes it. Interactive screens such
-- as MoveLearnMenu/PartyMenu are NEVER auto-answered: instead we mark them as
-- native modals so RealtimeBattle freezes direct-control movement/attacks and
-- gives the real engine screen/input exclusive ownership until it closes.
local function realtimeNativeModal(game)
  local battle=R.activeBattle
  if not (battle and realtimeOwnsPresentation(battle) and game and game.stack) then
    if battle then battle.__xdRealtimeNativeModal=nil end
    R.nativeModalName=nil
    return nil,nil
  end
  local top=stackTop(game)
  if not top or top==battle then
    battle.__xdRealtimeNativeModal=nil
    R.nativeModalName=nil
    return nil,top
  end
  local req=V.engineRequire or require
  local ok,BattleState=pcall(req,"src.battle.BattleState")
  if ok and type(BattleState)=="table" and type(BattleState.StatBox)=="table"
      and getmetatable(top)==BattleState.StatBox then
    return "StatBox",top
  end
  local okChoice,ChoiceBox=pcall(req,"src.ui.ChoiceBox")
  if okChoice and type(ChoiceBox)=="table" and getmetatable(top)==ChoiceBox then
    return "ChoiceBox",top
  end
  local id=rawget(top,"screenId")
  if id~=nil then return tostring(id),top end
  return "native-ui",top
end

local function serviceRealtimeQueueUi(game)
  local battle=R.activeBattle
  if not (battle and realtimeOwnsPresentation(battle)) then return false end
  local name,top=realtimeNativeModal(game)
  if not name then return false end

  -- Level-up stat pages have no decision attached to them. Pop the exact
  -- exported BattleState.StatBox and preserve its optional onDone callback.
  if name=="StatBox" and battle.waitingUI and stackTop(game)==top then
    local popped=game.stack:pop()
    if popped and type(popped.onDone)=="function" then pcall(popped.onDone) end
    R.statBoxAutoDismissed=(tonumber(R.statBoxAutoDismissed) or 0)+1
    R.nativeModalName=nil
    battle.__xdRealtimeNativeModal=nil
    return true
  end

  -- Belt-and-suspenders for the trainer SHIFT prompt: v0.6.27 already runs
  -- enemyMonFainted() as SET style, but if another mod/wrapper reintroduces
  -- the ChoiceBox, decline ONLY the post-KO trainer free-switch question.
  local enemy=battle.enemy and battle.enemy.mon
  if name=="ChoiceBox" and battle.kind=="trainer" and battle.waitingUI
      and enemy and (tonumber(enemy.hp) or 0)<=0
      and battle.current and battle.current.choice and stackTop(game)==top then
    local popped=game.stack:pop()
    if popped and type(popped.onChoose)=="function" then pcall(popped.onChoose,false) end
    R.trainerChoiceAutoDeclined=(tonumber(R.trainerChoiceAutoDeclined) or 0)+1
    R.nativeModalName=nil
    battle.__xdRealtimeNativeModal=nil
    return true
  end

  -- Real decisions (MoveLearnMenu, PartyMenu, etc.) stay native and must be
  -- answered by the player. RealtimeBattle reads this marker and stops direct
  -- locomotion/attacks while the top state owns input.
  R.nativeModalName=name
  battle.__xdRealtimeNativeModal=name
  return false
end

local function installHardRealtimeMenuQuarantine()
  if R.hardMenuQuarantine then return true end
  local req=V.engineRequire or require
  local ok,BattleState=pcall(req,"src.battle.BattleState")
  if not ok or type(BattleState)~="table" or type(BattleState.update)~="function" then return false end
  local inner=BattleState.update
  R.nativeBattleUpdateInner=inner
  R.nativeBattleUpdateWrapper=function(self,dt,...)
    if self~=R.activeBattle or not realtimeOwnsBattleInput(self.game) then return inner(self,dt,...) end

    -- IMPORTANT: quarantine ONLY the two hidden command-menu phases. Trainer
    -- replacement, faint/EXP, SHIFT/SET and victory are all driven by the
    -- authoritative message queue. Wrapping those phases here can swallow the
    -- transition that pushes the YES/NO ChoiceBox or the next enemy send-out.
    -- Message A/B auto-advance is already handled by updateQueue + input.step.
    if self.phase~="menu" and self.phase~="moveSelect" then
      return inner(self,dt,...)
    end

    -- If an old/raw input edge ever put the hidden engine menu into moveSelect,
    -- immediately return it to the neutral command phase. Realtime attacks never
    -- use this phase; they call executeAction/performMove only after spatial hit.
    if self.phase=="moveSelect" and not self.__xdRealtimeAllowNativeMenu then
      self.phase="menu";self.moveSwapIndex=nil
    end
    if self.phase=="menu" then self.menuIndex=1 end

    local input=self.game and self.game.input
    if type(input)~="table" then return inner(self,dt,...) end
    local wasPressed,isDown,wasReleased=input.wasPressed,input.isDown,input.wasReleased
    if type(wasPressed)=="function" then
      input.wasPressed=function(obj,key,...)
        local k=tostring(key):lower()
        if self.phase=="messages" and (k=="a" or k=="b") then return true end
        if NATIVE_BATTLE_INPUT_BLOCK[k] then return false end
        return wasPressed(obj,key,...)
      end
    end
    if type(isDown)=="function" then
      input.isDown=function(obj,key,...)
        local k=tostring(key):lower()
        if self.phase=="messages" and (k=="a" or k=="b") then return true end
        if NATIVE_BATTLE_INPUT_BLOCK[k] then return false end
        return isDown(obj,key,...)
      end
    end
    if type(wasReleased)=="function" then
      input.wasReleased=function(obj,key,...)
        if NATIVE_BATTLE_INPUT_BLOCK[tostring(key):lower()] then return false end
        return wasReleased(obj,key,...)
      end
    end
    local results={pcall(inner,self,dt,...)}
    input.wasPressed,input.isDown,input.wasReleased=wasPressed,isDown,wasReleased
    local passed=table.remove(results,1)
    if not passed then error(results[1],0) end
    return (table.unpack or unpack)(results)
  end
  BattleState.update=R.nativeBattleUpdateWrapper
  R.hardMenuQuarantine=true
  return true
end

function R.install()
  if R.installed then
    installFinishBoundary()
    installCaptureSoundBridge()
    installRawRealtimeInputCapture()
    installRealtimeMessageAdvanceBridge()
    installRealtimeNativeFxSuppression()
    installTrainerItemActionBridge()
    installRealtimeTrainerReplacementBridge()
    installHardRealtimeMenuQuarantine()
    return true
  end

  installFinishBoundary()
  installCaptureSoundBridge()
  installRawRealtimeInputCapture()
  installRealtimeMessageAdvanceBridge()
  installRealtimeNativeFxSuppression()
  installTrainerItemActionBridge()
  installRealtimeTrainerReplacementBridge()
  installHardRealtimeMenuQuarantine()

  if mod.hooks and type(mod.hooks.wrap)=="function" then
    mod.hooks:wrap("input.step",function(next,game,dt)
      -- An encounter transition is pushed DURING the engine step. Snapshot the
      -- stack so CBE can guarantee that no background cache/model job runs
      -- after that push but before the transition gets its first draw. This was
      -- the hidden source of the 5-10 second "encounter happened, wipe has not
      -- appeared yet" pause on slower Android storage/GPUs.
      local topBefore=stackTop(game)
      local result=callEngineStepWithRealtimeInputBlocked(next,game,dt)
      -- Service any queue-owned native modal immediately after the engine step.
      -- Informational level-up StatBox pages are closed here; real choice UIs
      -- remain on the stack and are marked for RealtimeBattle to pause behind.
      if R.activeBattle then pcall(serviceRealtimeQueueUi,game) end
      local topAfter=stackTop(game)
      local stateChanged=topBefore~=topAfter
      if R.activeBattle and R.activeBattle.__xdRealtimeResolution
          and R.activeBattle.phase=="menu" then
        R.activeBattle.__xdRealtimeResolution=nil
      end
      if BattleDirector and R.activeBattle and type(BattleDirector.update)=="function" then
        pcall(BattleDirector.update,BattleDirector,contextFor(R.activeBattle),dt)
      end
      if ANDROID_RUNTIME then
        local t=wallNow()
        if not R.activeBattle then
          -- Only a tiny incremental GC step remains in interactive overworld
          -- frames, and even that is skipped on ANY state-transition frame.
          -- Arena, trainer, Pokemon and MoveFX materialization now happens at
          -- explicit game-ready/battle-ready seams instead of opportunistically
          -- inside player input.
          if not stateChanged and t>=androidGcNextAt and PokemonActors and type(PokemonActors.gcStep)=="function" then
            pcall(PokemonActors.gcStep,24);androidGcNextAt=t+0.18
          end
        elseif not stateChanged and t>=androidActionWarmNextAt and PokemonActors and type(PokemonActors.pumpActionPrewarm)=="function" then
          -- Native action banks are exact source data but no longer all upload in
          -- battle.started. Drain one small bank at a time only after the battle
          -- screen is already stable, independent of battle speed.
          pcall(PokemonActors.pumpActionPrewarm,1);androidActionWarmNextAt=t+0.18
        end
      end
      if StandaloneHost then
        -- Last-resort arbitration seam: if a later-priority mod rewrapped
        -- BattleState after battle.started, reclaim the outer slot before the
        -- next frame. install() is effectively free while our wrapper is still
        -- current and only creates a new epoch when it was actually displaced.
        if R.activeBattle then pcall(StandaloneHost.install,true) end
        StandaloneHost.update(dt)
      end
      return result
    end)
  end

  if mod.events and type(mod.events.on)=="function" then
    mod.events:on("battle.started",beginBattle)
    for _,name in ipairs(SEMANTIC_EVENTS) do
      mod.events:on(name,function(payload) dispatch(name,payload) end)
    end
    mod.events:on("battle.ended",endBattle)
  end

  R.installed=true
  return true
end

function R.status()
  return {installed=R.installed,active=R.activeBattle~=nil,pendingEnd=R.pendingEnd~=nil,
    endBoundary="battle.screen.finished",finishBoundaryInstalled=R.finishBoundaryInstalled==true,
    captureSoundBridge=R.captureSoundBridge==true,nativeCaughtSuppressed=R.nativeCaughtSuppressed or 0,
    moveSoundBridge=R.moveSoundBridge==true,nativeMoveSoundsSuppressed=R.nativeMoveSoundsSuppressed or 0,
    modelPrewarm=R.modelPrewarm,entryTiming=R.entryTiming,exitTiming=R.exitTiming,
    rawRealtimeInputCapture=R.rawInputCaptureInstalled==true,hardMenuQuarantine=R.hardMenuQuarantine==true,realtimeWheelBuffered=tonumber(R.realtimeWheelY) or 0,
    nativeBattleFlashSuppressed=R.nativeFxBridge==true,trainerItemActionBridge=R.trainerItemBridge==true,
    trainerReplacementBridge=R.trainerReplacementBridge==true,realtimeQueueUiBridge=true,
    statBoxAutoDismissed=R.statBoxAutoDismissed or 0,trainerChoiceAutoDeclined=R.trainerChoiceAutoDeclined or 0,nativeModalName=R.nativeModalName,
    realtimeLatchedKeys=R.realtimeKeyPressed,
    captureSuccessAudio="ISO me_snatch owns success; native Caught_Mon suppressed only when source cue is available",
    moveAudio="Waza type-5 GameSound owns native battle-animation SFX only when the complete generated snd_se_battle WAV set is present"}
end

return R
