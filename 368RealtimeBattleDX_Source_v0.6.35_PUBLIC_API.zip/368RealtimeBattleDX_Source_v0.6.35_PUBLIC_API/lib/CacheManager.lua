local V=...
local mod=V.mod
local GeneratedAssets=V.GeneratedAssets
local C={schema=1,lastAction=nil,cacheVersion=1,extractorRevision=1}
local ARENA_MARKER=[=[xdbe-arena=1
source=GXXE01-stage-pack
water=M1_water_colo.fsys/M1_water_colo.dat/source-hsd-scene-v32
orre=T1_ancient_colo.fsys/T1_ancient_colo.dat/source-hsd-scene-v32
realgam=D4_casino_colo.fsys/D4_casino_colo.dat/source-hsd-scene-v32
summit=D2_crater_colo.fsys/D2_crater_colo.dat/source-hsd-scene-v32
wildlands=bundled-authored-fallback
]=]
local CORE={"cache/M1_water_cache.lua","cache/orre_colosseum_cache.lua","cache/realgam_colosseum_cache.lua","cache/outdoor_wild_cache.lua","cache/D2_mt_battle_platform100_cache.lua"}
local function read(path)return GeneratedAssets.read(path) end
local function exists(path)return GeneratedAssets.exists(path) end
local function importInfo()
  if not (mod.imports and type(mod.imports.info)=="function") then return nil end
  local ok,v=pcall(mod.imports.info,mod.imports,"pokemon_xd_stage_pack");return ok and v or nil
end
local function parseState(raw)local out={};if type(raw)~="string" then return out end;for line in raw:gmatch("[^\r\n]+") do local k,v=line:match("^([%w_%.%-]+)=(.*)$");if k then out[k]=v end end;return out end
local function prettyBytes(n)n=tonumber(n) or 0;if n>=1024^3 then return ("%.2f GiB"):format(n/1024^3) elseif n>=1024^2 then return ("%.1f MiB"):format(n/1024^2) elseif n>=1024 then return ("%.1f KiB"):format(n/1024) end;return tostring(n).." B" end
function C.inspect()
  local rom=importInfo();local state=parseState(read("build/state.txt"));local marker=read(".xdbe-arena-v1.complete")
  local have=0;local missing={};for _,p in ipairs(CORE) do if exists(p) then have=have+1 else missing[#missing+1]=p end end
  local ready=rom~=nil and marker==ARENA_MARKER and have==#CORE
  local err=read("build/error.txt");if type(err)=="string" then err=err:gsub("[%s\r\n]+$","") end
  local status=ready and "XD ARENAS READY" or (err and err~="" and "EXTRACTION FAILED" or (rom and "STAGE PACK IMPORTED / BUILD PENDING" or "IMPORT STAGE PACK REQUIRED"))
  return {schema=C.schema,ready=ready,runtimeReady=ready,fullRuntimeReady=ready,visualReady=ready,audioReady=false,sourceReady=rom~=nil,sourceImported=rom~=nil,sourceStatus=status,source=status,generated=marker~=nil,generatedRuntime=ready,arenaMarker=marker,files=tonumber(state.fst_files) or 0,sourceFiles=tonumber(state.fst_files) or 0,sourceBytes=rom and (tonumber(rom.size) or 0) or 0,sourceSizeLabel=prettyBytes(rom and (tonumber(rom.size) or 0) or 0),sourceFingerprint=rom and "GXXE01 / HTML stage pack" or nil,missing=missing,componentCounts={arenas={have=have,total=#CORE}},stages={arenas=exists("build/stage_arenas.complete")},discId="GXXE01",discRegion="USA",cacheVersion=C.cacheVersion,extractionCacheVersion=C.cacheVersion,extractorRevision=C.extractorRevision,trainerResolved=0,trainerTotal=0,sourceAccess=rom and "VALIDATED / BOUNDED" or "NOT AVAILABLE",currentStage=state.current_stage,lastAction=err or state.message or C.lastAction}
end
local function callReset(name)local m=V[name];if m and type(m.resetRuntime)=="function" then pcall(m.resetRuntime,m) end;if m and type(m.invalidate)=="function" then pcall(m.invalidate,m) end end
function C.resetRuntime() for _,name in ipairs({"Arena","CurrentSpriteModels","StandaloneHost"}) do callReset(name) end;collectgarbage("collect");C.lastAction="XD arena runtime objects cleared.";return true,C.lastAction end
function C.resetGenerated()
  local raw=read("build/generated_paths.lua")
  if raw then local chunk=load(raw,"@generated/build/generated_paths.lua");local ok,paths=false,nil;if chunk then ok,paths=pcall(chunk) end;if ok and type(paths)=="table" then for _,p in ipairs(paths) do GeneratedAssets.delete(p) end end end
  for _,p in ipairs({".xdbe-arena-v1.complete","build/error.txt","build/state.txt","build/generated_paths.lua","build/stage_arenas.complete","build/disc_index.lua"}) do GeneratedAssets.delete(p) end
  C.lastAction="Generated XD arena runtime cleared. Reload the mod to rebuild from the imported XD stage pack.";return true,C.lastAction
end
function C.status()return C.inspect() end
function C.prettyBytes(n)return prettyBytes(n) end
return C
