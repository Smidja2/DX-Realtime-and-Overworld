# v0.6.35 Public Provider API

- Added automatic `battleModelProvider` discovery for simple custom model packs.
- Added `realtimeBattleAPI` / `battleFramework` registration facade.
- Added layered per-species actor fallback: partial custom pack -> next 3D provider -> sprite.
- Added mixed-provider rendering so player/enemy may come from different model packs.
- Added layered `battleMoveFX` / `battleMoveProvider` fallback per move.
- Added `battleMoveBehavior` / `realtimeMoveBehavior` for custom move targeting profiles.
- Added `{remapTo="MOVE_NAME"}` behavior inheritance for custom move IDs.
- Preserved native Gen1Recomp ownership of PP, damage, accuracy, status, EXP, switching and battle outcomes.
- Preserved XD as a compatibility fallback rather than a hard requirement for models/VFX.
- Added public API documentation and a custom provider example.
