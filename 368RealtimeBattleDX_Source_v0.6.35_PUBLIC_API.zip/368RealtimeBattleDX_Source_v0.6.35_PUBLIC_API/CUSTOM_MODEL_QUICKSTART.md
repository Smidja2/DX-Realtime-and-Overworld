# Custom Model Pack Quick Start

If your mod already knows how to load and draw its own Pokemon models, you only
need to expose `mod.exports.battleModelProvider`.

Minimum useful provider:

```lua
local mod=...

mod.exports.battleModelProvider={
  version=1,
  priority=200,

  hasSpecies=function(dex)
    return MyModels.has(dex)
  end,

  createActor=function(dex,opts)
    return MyModels.loadActor(dex)
  end,

  matrix=function(actor,x,y,z,fx,fz)
    return actor:matrix(x,y,z,fx,fz)
  end,

  draw=function(actor,matrix,alpha)
    return actor:draw(matrix,alpha)
  end,
}
```

That is enough for model ownership. Add `setAnimation` or actor methods such as
`attack`, `hit`, `faint`, `locomotion`, and `idle` for animation support.

If your renderer needs its own shader/camera setup, add `withRenderer(vp,cb,opts)`.

If your custom pack also adds moves, export `battleMoveBehavior` and optionally
`battleMoveFX`. A new move can inherit an existing targeting profile with one
line:

```lua
if moveId==9001 then return {remapTo="THUNDERBOLT"} end
```

See `PUBLIC_MODDING_API.md` and `examples/CustomBattleProviderExample/`.
