local M={}
local IMPORT_ID="pokemon_xd_stage_pack"
local MAGIC="XDBSTG01"
local REQUIRED={
  "M1_water_colo.dat",
  "T1_ancient_colo.dat",
  "D4_casino_colo.dat",
  "D2_crater_colo.dat",
}

local function u16le(s,p)
  local a,b=s:byte(p,p+1);if not b then return nil end
  return a+b*256
end
local function u32le(s,p)
  local a,b,c,d=s:byte(p,p+3);if not d then return nil end
  return a+b*256+c*65536+d*16777216
end
local function clean(s)return tostring(s or ""):gsub("[%z\1-\31]","_")end

function M.open(mod)
  assert(mod and mod.imports,"mod.imports is required")
  local info,err=mod.imports:info(IMPORT_ID)
  assert(info,err or "XD battle-stage pack unavailable")
  local packSize=tonumber(info.size or info.length or 0) or 0
  assert(packSize>=64 and packSize<=64*1024*1024,"XD battle-stage pack size is invalid")

  local function rawRead(offset,length)
    assert(type(offset)=="number" and type(length)=="number" and offset>=0 and length>=0,"invalid stage-pack range")
    if length==0 then return "" end
    assert(offset+length<=packSize,"stage-pack read exceeds source")
    local parts={};local at=offset;local left=length
    while left>0 do
      local n=math.min(left,8*1024*1024)
      local bytes,e=mod.imports:read(IMPORT_ID,at,n);assert(bytes,e or "stage-pack read failed")
      assert(type(bytes)=="string" and #bytes==n,"short stage-pack read")
      parts[#parts+1]=bytes;at=at+n;left=left-n
    end
    return table.concat(parts)
  end

  local fixed=rawRead(0,16)
  assert(fixed:sub(1,8)==MAGIC,"invalid XD battle-stage pack magic")
  local version=u32le(fixed,9)
  local count=u32le(fixed,13)
  assert(version==1,"unsupported XD battle-stage pack version: "..tostring(version))
  assert(count and count>0 and count<=32,"invalid XD battle-stage pack entry count")

  local head=rawRead(0,math.min(packSize,4096))
  local p=17
  local self={mod=mod,info=info,files={},byPath={},byBase={},packSize=packSize,source="368BattlePackDX.pack"}
  function self:read(offset,length)return rawRead(offset,length)end
  for i=1,count do
    local nl=u16le(head,p);assert(nl and nl>0 and nl<=255,"invalid stage-pack name length")
    p=p+2
    assert(p+nl+24-1<=#head,"truncated XD battle-stage index")
    local name=clean(head:sub(p,p+nl-1));p=p+nl
    local off=u32le(head,p);p=p+4
    local size=u32le(head,p);p=p+4
    local md5=head:sub(p,p+15);p=p+16
    assert(off and size and size>0 and off+size<=packSize,"invalid XD battle-stage member range: "..name)
    local f={path=name,offset=off,size=size,index=i,md5=md5}
    self.files[#self.files+1]=f
    self.byPath[name:lower()]=f
    local base=name:lower():match("([^/]+)$")
    self.byBase[base]=self.byBase[base] or {}
    self.byBase[base][#self.byBase[base]+1]=f
  end

  function self:file(path)
    if not path then return nil end
    local q=tostring(path):lower();local hit=self.byPath[q];if hit then return hit end
    local base=q:match("([^/]+)$");local hits=self.byBase[base];return hits and hits[1] or nil
  end
  function self:find(pattern)
    pattern=tostring(pattern or ""):lower();local out={}
    for _,f in ipairs(self.files) do if f.path:lower():find(pattern,1,true) then out[#out+1]=f end end
    return out
  end
  function self:readFile(file,off,len)
    if type(file)=="string" then file=assert(self:file(file),"stage file not found: "..file) end
    off=off or 0;len=len or (file.size-off)
    assert(off>=0 and len>=0 and off+len<=file.size,"stage-file read exceeds member")
    return rawRead(file.offset+off,len)
  end

  for _,name in ipairs(REQUIRED) do
    local f=assert(self:file(name),"XD stage pack missing "..name)
    local tailN=math.min(f.size,4096)
    local tail=self:readFile(f,f.size-tailN,tailN)
    assert(tail:find("scene_data",1,true),name.." is not a decoded HSD stage DAT")
  end
  table.sort(self.files,function(a,b)return a.path<b.path end)
  return self
end

function M.serializeIndex(disc)
  local out={"return {source=\"368BattlePackDX.pack\",discId=\"GXXE01\",size=",disc.info.size or 0,",files={\n"}
  for _,f in ipairs(disc.files) do out[#out+1]=string.format("{%q,%d,%d},\n",f.path,f.offset,f.size) end
  out[#out+1]="}}\n";return table.concat(out)
end
return M
