local V=...
local Disc=V.GameCubeDisc
local ArenaBuilder=V.ArenaBuilder
local B={cacheVersion=2,extractorRevision=2}

local ARENA_MARKER=[=[xdbe-arena=1
source=GXXE01-direct-hsd-pack
water=M1_water_colo.dat/source-hsd-scene-v32
orre=T1_ancient_colo.dat/source-hsd-scene-v32
realgam=D4_casino_colo.dat/source-hsd-scene-v32
summit=D2_crater_colo.dat/source-hsd-scene-v32
wildlands=bundled-authored-fallback
]=]
local CORE={
  "cache/M1_water_cache.lua",
  "cache/orre_colosseum_cache.lua",
  "cache/realgam_colosseum_cache.lua",
  "cache/outdoor_wild_cache.lua",
  "cache/D2_mt_battle_platform100_cache.lua",
}
local function call(obj,name,...)
  if not obj or type(obj[name])~="function" then return nil,"unavailable" end
  local ok,a,b=pcall(obj[name],obj,...);if not ok then return nil,tostring(a) end;return a,b
end
local function read(mod,path)local v=select(1,call(mod.cache,"read",path));return type(v)=="string" and v or nil end
local function exists(mod,path)local v=select(1,call(mod.cache,"info",path));return type(v)=="table" and (v.type==nil or v.type=="file") end
local function write(mod,path,data,generated)
  local ok,err=call(mod.cache,"write",path,data);assert(ok,err or ("cache write failed: "..path));if generated then generated[#generated+1]=path end
end
local function del(mod,path) call(mod.cache,"delete",path) end
local function ready(mod)
  if read(mod,".xdbe-arena-v2.complete")~=ARENA_MARKER then return false end
  for _,p in ipairs(CORE) do if not exists(mod,p) then return false end end
  return true
end
local function stateText(disc,message,stage)
  return table.concat({
    "cache_version="..B.cacheVersion,
    "extractor_revision="..B.extractorRevision,
    "current_stage="..tostring(stage or "ready"),
    "message="..tostring(message or "XD arena runtime ready"),
    "disc_id=GXXE01",
    "source_kind=direct-hsd-pack",
    "disc_region=USA",
    "source_size="..tostring(disc and disc.info and disc.info.size or 0),
    "fst_files="..tostring(disc and disc.files and #disc.files or 0),
    "fsys_files="..tostring(disc and disc.files and #disc:find(".fsys") or 0),
    "visual_ready=1",
    "audio_ready=0",
  },"\n").."\n"
end
local function finishManifest(mod,generated)
  local rows={"return {\n"}
  table.sort(generated)
  for _,p in ipairs(generated) do rows[#rows+1]=string.format("%q,\n",p) end
  rows[#rows+1]="}\n"
  write(mod,"build/generated_paths.lua",table.concat(rows),nil)
end
function B.run(mod,progress)
  progress=progress or function() end
  assert(mod and mod.imports and mod.cache,"368RealtimeBattleDX requires mod.imports/mod.cache")
  if ready(mod) then
    local info=select(1,call(mod.imports,"info","pokemon_xd_stage_pack"))
    return {state="READY",visualReady=true,audioReady=false,message="XD stage-pack battle-environment cache ready",disc_id="GXXE01",disc_region="USA",source_size=info and info.size or 0}
  end
  local generated={}
  del(mod,"build/error.txt")
  progress("XD STAGE PACK INDEX",0,2)
  local disc=Disc.open(mod)
  write(mod,"build/disc_index.lua",Disc.serializeIndex(disc),generated)
  write(mod,"build/state.txt",stateText(disc,"Extracting XD battle environments","arenas"),generated)
  progress("XD ARENAS",1,2)
  local ok,err=pcall(ArenaBuilder.run,mod,disc,progress,generated)
  if not ok then
    local msg=tostring(err)
    write(mod,"build/error.txt",msg.."\n",generated)
    write(mod,"build/state.txt",stateText(disc,msg,"failed"),generated)
    finishManifest(mod,generated)
    return {state="FAILED",visualReady=false,audioReady=false,message=msg,disc_id="GXXE01",disc_region="USA"}
  end
  write(mod,".xdbe-arena-v2.complete",ARENA_MARKER,generated)
  write(mod,"build/stage_arenas.complete","GXXE01 arenas ready\n",generated)
  write(mod,"build/state.txt",stateText(disc,"XD battle-environment cache ready","ready"),generated)
  finishManifest(mod,generated)
  progress("XD ENVIRONMENTS READY",2,2)
  return {state="READY",visualReady=true,audioReady=false,message="XD stage-pack battle-environment cache ready",disc_id="GXXE01",disc_region="USA",fst_files=#disc.files}
end
function B.ensureFormatProbe(mod,_,force)
  return false,"Environment-only XD fork does not build Colosseum WZX/CAM format probes"
end
return B
